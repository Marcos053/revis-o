package SistemaDeAlbuns_e_Artistas;

import java.util.Scanner;

public class Banda extends Artista {
    private Integer anoFormacao;

    public Banda(Integer id, String nome, String pais, Integer anoFormacao) {
        super(id, nome, pais);
        this.anoFormacao = anoFormacao;
    }

    public Integer getAnoFormacao() { return anoFormacao; }
    public void setAnoFormacao(Integer anoFormacao) { this.anoFormacao = anoFormacao; }

    @Override
    public String toString() {
        return "[BANDA] " + super.toString() + " | Formação: " + anoFormacao;
    }

    public static Banda lerDados(Scanner scanner) {
        System.out.print("ID: ");
        Integer id = Integer.parseInt(scanner.nextLine());
        System.out.print("Nome da Banda: ");
        String nome = scanner.nextLine();
        System.out.print("País de Origem: ");
        String pais = scanner.nextLine();
        System.out.print("Ano de Formação: ");
        Integer ano = Integer.parseInt(scanner.nextLine());
        
        return new Banda(id, nome, pais, ano);
    }
}
