package SistemaDeAlbuns_e_Artistas;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Album {
    private Integer id;
    private String titulo;
    private LocalDate dataLancamento;
    private Artista artistaPrincipal;
    private List<Integrante> integrantes;
    private GeneroMusical genero;

    public Album(Integer id, String titulo, LocalDate dataLancamento, Artista artistaPrincipal, GeneroMusical genero) {
        this.id = id;
        this.titulo = titulo;
        this.dataLancamento = dataLancamento;
        this.artistaPrincipal = artistaPrincipal;
        this.genero = genero;
        this.integrantes = new ArrayList<>();
    }

    public Integer getId() { return id; }
    public String getTitulo() { return titulo; }
    public LocalDate getDataLancamento() { return dataLancamento; }
    public Artista getArtistaPrincipal() { return artistaPrincipal; }
    public GeneroMusical getGenero() { return genero; }
    public List<Integrante> getIntegrantes() { return integrantes; }

    public void adicionarIntegrante(Integrante integrante) {
        this.integrantes.add(integrante);
    }

    @Override
    public String toString() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return "ÁLBUM [" + genero + "] " + titulo + " | Artista Principal: " + artistaPrincipal.getNome() + 
               " | Lançamento: " + dataLancamento.format(fmt) + " | Qtd. Integrantes: " + integrantes.size();
    }

    public static Album lerDados(Scanner scanner, Artista artista, GeneroMusical genero) {
        System.out.print("ID do Álbum: ");
        Integer id = Integer.parseInt(scanner.nextLine());
        System.out.print("Título: ");
        String titulo = scanner.nextLine();
        System.out.print("Data de Lançamento (DD/MM/AAAA): ");
        String dataStr = scanner.nextLine();
        
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate dataLancamento = LocalDate.parse(dataStr, fmt);
        
        return new Album(id, titulo, dataLancamento, artista, genero);
    }
}
