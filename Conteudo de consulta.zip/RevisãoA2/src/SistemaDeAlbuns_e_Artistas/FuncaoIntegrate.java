package SistemaDeAlbuns_e_Artistas;

public enum FuncaoIntegrate {
    VOCALISTA(1), GUITARRISTA(2), BAIXISTA(3), TECLADISTA(4), BATERISTA(5);
    
    private final int valor;
    
    FuncaoIntegrate(int valor) { this.valor = valor; }
    public int getValor() { return valor; }
}
