package SistemaDeAlbuns_e_Artistas;

public abstract class Artista {
    private Integer id;
    private String nome;
    private String pais;

    public Artista(Integer id, String nome, String pais) {
        this.id = id;
        this.nome = nome;
        this.pais = pais;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getPais() { return pais; }
    public void setPais(String pais) { this.pais = pais; }

    @Override
    public String toString() {
        return "ID: " + id + " | Nome: " + nome + " | País: " + pais;
    }
}