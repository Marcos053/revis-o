package SistemaDeAlbuns_e_Artistas;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Principal {
    private static List<Artista> artistas = new ArrayList<>();
    private static List<Album> albuns = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcao = -1;
        while (opcao != 6) {
            System.out.println("\n=== GESTÃO MUSICAL ===");
            System.out.println("1. Inserir Artista");
            System.out.println("2. Inserir Álbum");
            System.out.println("3. Listar Todos os Artistas");
            System.out.println("4. Listar os Álbuns");
            System.out.println("5. Listar Artistas (Integrantes) de um Álbum");
            System.out.println("6. Sair");
            System.out.print("Escolha: ");
            
            opcao = Integer.parseInt(scanner.nextLine());

            switch (opcao) {
                case 1: inserirArtista(); break;
                case 2: inserirAlbum(); break;
                case 3: imprimirArtistas(); break;
                case 4: imprimirAlbuns(); break;
                case 5: listarArtistasDeUmAlbum(); break;
                case 6: System.out.println("Encerrando..."); break;
                default: System.out.println("Opção inválida!");
            }
        }
    }

    private static void inserirArtista() {
        System.out.println("\n--- CADASTRAR ARTISTA ---");
        System.out.println("1 - Pessoa (Solo) | 2 - Banda");
        System.out.print("Tipo: ");
        int tipo = Integer.parseInt(scanner.nextLine());

        if (tipo == 1) {
            artistas.add(Pessoa.lerDados(scanner));
            System.out.println("Pessoa cadastrada com sucesso!");
        } else if (tipo == 2) {
            artistas.add(Banda.lerDados(scanner));
            System.out.println("Banda cadastrada com sucesso!");
        } else {
            System.out.println("Opção inválida.");
        }
    }

    private static void inserirAlbum() {
        if (artistas.isEmpty()) {
            System.out.println("Cadastre ao menos um Artista primeiro.");
            return;
        }

        System.out.println("\n--- CADASTRAR ÁLBUM ---");
        System.out.println("Generos: 1-POP, 2-ROCK, 3-JAZZ, 4-HIPHOP, 5-BLUES, 6-FOLK");
        System.out.print("Escolha o Gênero: ");
        int genOp = Integer.parseInt(scanner.nextLine());
        GeneroMusical genero = GeneroMusical.values()[genOp - 1];

        System.out.println("Selecione o Artista Principal pelo ID:");
        artistas.forEach(a -> System.out.println(a));
        System.out.print("ID do Artista: ");
        int idArt = Integer.parseInt(scanner.nextLine());
        
        Artista artPrinc = artistas.stream().filter(a -> a.getId() == idArt).findFirst().orElse(null);
        
        if (artPrinc == null) {
            System.out.println("Artista não encontrado.");
            return;
        }

        Album novoAlbum = Album.lerDados(scanner, artPrinc, genero);

        // Adicionando Integrantes (Apenas Pessoas)
        List<Artista> pessoas = buscarArtistas(1); // Filtra só pessoas
        if (!pessoas.isEmpty()) {
            String continuar = "s";
            while (continuar.equalsIgnoreCase("s")) {
                System.out.println("\nAdicionar Integrante ao Álbum:");
                pessoas.forEach(p -> System.out.println(p));
                System.out.print("ID da Pessoa: ");
                int idPessoa = Integer.parseInt(scanner.nextLine());
                
                Pessoa pessoa = (Pessoa) pessoas.stream().filter(p -> p.getId() == idPessoa).findFirst().orElse(null);
                
                if (pessoa != null) {
                    System.out.println("Funções: 1-VOCALISTA, 2-GUITARRISTA, 3-BAIXISTA, 4-TECLADISTA, 5-BATERISTA");
                    System.out.print("Função: ");
                    int funcOp = Integer.parseInt(scanner.nextLine());
                    FuncaoIntegrate funcao = FuncaoIntegrate.values()[funcOp - 1];
                    
                    novoAlbum.adicionarIntegrante(new Integrante(pessoa, funcao));
                    System.out.println("Integrante adicionado.");
                } else {
                    System.out.println("Pessoa não encontrada.");
                }
                
                System.out.print("Adicionar outro? (s/n): ");
                continuar = scanner.nextLine();
            }
        }
        
        albuns.add(novoAlbum);
        System.out.println("Álbum salvo com sucesso!");
    }

    // Requisito: Buscar artistas por tipo (1 = Pessoa, 2 = Banda)
    private static List<Artista> buscarArtistas(int tipo) {
        if (tipo == 1) {
            return artistas.stream().filter(a -> a instanceof Pessoa).collect(Collectors.toList());
        } else {
            return artistas.stream().filter(a -> a instanceof Banda).collect(Collectors.toList());
        }
    }

    private static void imprimirArtistas() {
        System.out.println("\n--- LISTA DE ARTISTAS ---");
        
        // Uso de Lambda para ordenação exigida
        System.out.println(">> PESSOAS (SOLO):");
        buscarArtistas(1).stream()
            .sorted(Comparator.comparing(Artista::getNome))
            .forEach(a -> System.out.println(a));

        System.out.println("\n>> BANDAS:");
        buscarArtistas(2).stream()
            .sorted((a1, a2) -> a1.getNome().compareToIgnoreCase(a2.getNome()))
            .forEach(a -> System.out.println(a));
    }

    private static void imprimirAlbuns() {
        System.out.println("\n--- LISTA DE ÁLBUNS ---");
        // Requisito: Ordenar por Título
        albuns.stream()
              .sorted(Comparator.comparing(Album::getTitulo))
              .forEach(a -> System.out.println(a));
    }

    private static void listarArtistasDeUmAlbum() {
        System.out.print("\nDigite o Título do Álbum: ");
        String busca = scanner.nextLine();

        Album albumEncontrado = albuns.stream()
            .filter(a -> a.getTitulo().equalsIgnoreCase(busca))
            .findFirst().orElse(null);

        if (albumEncontrado != null) {
            System.out.println("\nIntegrantes do Álbum: " + albumEncontrado.getTitulo());
            // Requisito: Ordenar integrantes por Nome da Pessoa
            albumEncontrado.getIntegrantes().stream()
                .sorted((i1, i2) -> i1.getPessoa().getNome().compareToIgnoreCase(i2.getPessoa().getNome()))
                .forEach(i -> System.out.println(i));
        } else {
            System.out.println("Álbum não encontrado.");
        }
    }
}