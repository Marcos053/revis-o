package SistemaDeAlbuns_e_Artistas;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Objects;
import java.util.Scanner;

public class Pessoa extends Artista {
    private LocalDate dataNascimento;

    public Pessoa(Integer id, String nome, String pais, LocalDate dataNascimento) {
        super(id, nome, pais);
        this.dataNascimento = dataNascimento;
    }

    public LocalDate getDataNascimento() { return dataNascimento; }
    public void setDataNascimento(LocalDate dataNascimento) { this.dataNascimento = dataNascimento; }

   
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Pessoa pessoa = (Pessoa) obj;
        return Objects.equals(this.getId(), pessoa.getId());
    }

    @Override
    public String toString() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return "[PESSOA] " + super.toString() + " | Nascimento: " + dataNascimento.format(fmt);
    }

    public static Pessoa lerDados(Scanner scanner) {
        System.out.print("ID: ");
        Integer id = Integer.parseInt(scanner.nextLine());
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("País: ");
        String pais = scanner.nextLine();
        System.out.print("Data de Nascimento (DD/MM/AAAA): ");
        String dataStr = scanner.nextLine();
        
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate dataNasc = LocalDate.parse(dataStr, fmt);
        
        return new Pessoa(id, nome, pais, dataNasc);
    }
}
