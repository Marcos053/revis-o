package SistemaDeAlbuns_e_Artistas;

public class Integrante {
    private Pessoa pessoa;
    private FuncaoIntegrate funcao;

    public Integrante(Pessoa pessoa, FuncaoIntegrate funcao) {
        this.pessoa = pessoa;
        this.funcao = funcao;
    }

    public Pessoa getPessoa() { return pessoa; }
    public void setPessoa(Pessoa pessoa) { this.pessoa = pessoa; }
    public FuncaoIntegrate getFuncao() { return funcao; }
    public void setFuncao(FuncaoIntegrate funcao) { this.funcao = funcao; }

    @Override
    public String toString() {
        return pessoa.getNome() + " - Função: " + funcao.name();
    }
}
