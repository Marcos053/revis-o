package SistemaDeAlbuns_e_Artistas;

public enum GeneroMusical {
    POP(1), ROCK(2), JAZZ(3), HIPHOP(4), BLUES(5), FOLK(6);
    
    private final int valor;
    
    GeneroMusical(int valor) { this.valor = valor; }
    public int getValor() { return valor; }
}
