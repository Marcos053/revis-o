package SistemaDeGerenciamentoDeComputadores_e_Notebooks;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.IntStream;

public class Loja {
    // Atributo exigido
    private static List<Computador> listaComputador = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcao = -1;
        while (opcao != 6) { 
            System.out.println("\n=== GESTÃO DE COMPUTADORES ===");
            System.out.println("1. Inserir um Computador");
            System.out.println("2. Excluir um Computador");
            System.out.println("3. Listar Todos os Computadores");
            System.out.println("4. Listar os Notebooks (Ordenado por Peso)");
            System.out.println("5. Listar os Desktops (Ordenado por Fonte)");
            System.out.println("6. Sair");
            System.out.print("Escolha uma opção: ");
            
            opcao = Integer.parseInt(scanner.nextLine());

            switch (opcao) {
                case 1: inserirComputador(); break;
                case 2: excluirComputador(); break;
                case 3: listarTodos(); break;
                case 4: listarNotebooks(); break;
                case 5: listarDesktops(); break;
                case 6: System.out.println("Saindo do sistema..."); break;
                default: System.out.println("Opção inválida!");
            }
        }
    }

    private static void inserirComputador() {
        System.out.println("\n--- INSERIR COMPUTADOR ---");
        System.out.println("1 - Notebook | 2 - Desktop");
        System.out.print("Opção: ");
        int tipo = Integer.parseInt(scanner.nextLine());

        if (tipo == 1) {
            listaComputador.add(Notebook.lerDados(scanner));
            System.out.println("Notebook cadastrado com sucesso!");
        } else if (tipo == 2) {
            listaComputador.add(Desktop.lerDados(scanner));
            System.out.println("Desktop cadastrado com sucesso!");
        } else {
            System.out.println("Tipo inválido.");
        }
    }

    private static void excluirComputador() {
        System.out.print("\nDigite o ID do computador para excluir: ");
        Integer idBusca = Integer.parseInt(scanner.nextLine());
        
        // Uso de Collections (Lambda) para remoção
        boolean removido = listaComputador.removeIf(comp -> comp.getId().equals(idBusca));
        
        if (removido) {
            System.out.println("Computador excluído com sucesso.");
        } else {
            System.out.println("ID não encontrado.");
        }
    }

    private static void listarTodos() {
        System.out.println("\n--- LISTA GERAL (Ordenada por ID) ---");
        // Ordenação por ID conforme exigido [cite: 725]
        listaComputador.sort(Comparator.comparing(Computador::getId));
        
        // Imprimindo a posição e o toString conforme exigido [cite: 733]
        for (int i = 0; i < listaComputador.size(); i++) {
            System.out.print("Posição [" + i + "] -> ");
            listaComputador.get(i).imprimir(); 
        }
    }

    private static void listarNotebooks() {
        System.out.println("\n--- LISTA DE NOTEBOOKS (Ordenada por Peso) ---");
        // Filtro por instância e ordenação pelo atributo específico [cite: 726]
        listaComputador.stream()
            .filter(comp -> comp instanceof Notebook)
            .map(comp -> (Notebook) comp) // Faz o cast para acessar os métodos do Notebook
            .sorted(Comparator.comparing(Notebook::getPesoKg))
            .forEach(Notebook::imprimir);
    }

    private static void listarDesktops() {
        System.out.println("\n--- LISTA DE DESKTOPS (Ordenada por Potência da Fonte) ---");
        // Filtro por instância e ordenação pelo atributo específico [cite: 727]
        listaComputador.stream()
            .filter(comp -> comp instanceof Desktop)
            .map(comp -> (Desktop) comp)
            .sorted(Comparator.comparing(Desktop::getPotenciaFonte))
            .forEach(Desktop::imprimir);
    }
}
