package SistemaDeGerenciamentoDeComputadores_e_Notebooks;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Desktop extends Computador {
    private Integer potenciaFonte; 

    public Desktop(Integer id, LocalDate dataCadastro, String modelo, SistemaOperacional so, Integer potenciaFonte) {
        super(id, dataCadastro, modelo, so);
        this.potenciaFonte = potenciaFonte;
    }

    public Integer getPotenciaFonte() { return potenciaFonte; }
    public void setPotenciaFonte(Integer potenciaFonte) { this.potenciaFonte = potenciaFonte; }

    @Override
    public void imprimir() {
        System.out.println(this.toString());
    }

    @Override
    public String toString() {
        return "[DESKTOP] " + super.toString() + " | Fonte: " + potenciaFonte + "W";
    }

    public static Desktop lerDados(Scanner scanner) {
        System.out.print("ID: ");
        Integer id = Integer.parseInt(scanner.nextLine());
        System.out.print("Data de Cadastro (DD/MM/AAAA): ");
        String dataStr = scanner.nextLine();
        LocalDate data = LocalDate.parse(dataStr, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        System.out.print("Modelo: ");
        String modelo = scanner.nextLine();
        System.out.print("SO (1-WINDOWS, 2-MAC_OS, 3-LINUX): ");
        int soOp = Integer.parseInt(scanner.nextLine());
        SistemaOperacional so = SistemaOperacional.values()[soOp - 1];
        System.out.print("Potência da Fonte (W): ");
        Integer potencia = Integer.parseInt(scanner.nextLine());

        return new Desktop(id, data, modelo, so, potencia);
    }
}