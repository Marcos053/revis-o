package SistemaDeGerenciamentoDeComputadores_e_Notebooks;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public abstract class Computador implements Impressao {
    private Integer id;
    private LocalDate dataCadastro;
    private String modelo; 
    private SistemaOperacional sistemaOperacional; 

    public Computador(Integer id, LocalDate dataCadastro, String modelo, SistemaOperacional sistemaOperacional) {
        this.id = id;
        this.dataCadastro = dataCadastro;
        this.modelo = modelo;
        this.sistemaOperacional = sistemaOperacional;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public LocalDate getDataCadastro() { return dataCadastro; }
    public void setDataCadastro(LocalDate dataCadastro) { this.dataCadastro = dataCadastro; }
    public String getModelo() { return modelo; }
    public void setModelo(String modelo) { this.modelo = modelo; }
    public SistemaOperacional getSistemaOperacional() { return sistemaOperacional; }
    public void setSistemaOperacional(SistemaOperacional sistemaOperacional) { this.sistemaOperacional = sistemaOperacional; }

    // Sobrescrita do equals usando apenas o ID, conforme exigido
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Computador that = (Computador) obj;
        return Objects.equals(this.id, that.id);
    }

    @Override
    public String toString() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return "ID: " + id + " | Modelo: " + modelo + 
               " | SO: " + sistemaOperacional.name() + 
               " | Data: " + dataCadastro.format(fmt);
    }
}
