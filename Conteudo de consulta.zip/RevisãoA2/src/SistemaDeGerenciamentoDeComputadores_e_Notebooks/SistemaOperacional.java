package SistemaDeGerenciamentoDeComputadores_e_Notebooks;


public enum SistemaOperacional {
 WINDOWS(1), MAC_OS(2), LINUX(3);
 
 private final int valor;
 
 SistemaOperacional(int valor) { 
     this.valor = valor; 
 }
 
 public int getValor() { 
     return valor; 
 }
}
