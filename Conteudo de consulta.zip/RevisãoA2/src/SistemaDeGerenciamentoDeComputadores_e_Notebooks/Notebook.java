package SistemaDeGerenciamentoDeComputadores_e_Notebooks;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Notebook extends Computador {
    private Double pesoKg; 

    public Notebook(Integer id, LocalDate dataCadastro, String modelo, SistemaOperacional so, Double pesoKg) {
        super(id, dataCadastro, modelo, so);
        this.pesoKg = pesoKg;
    }

    public Double getPesoKg() { return pesoKg; }
    public void setPesoKg(Double pesoKg) { this.pesoKg = pesoKg; }

    @Override
    public void imprimir() {
        System.out.println(this.toString());
    }

    @Override
    public String toString() {
        return "[NOTEBOOK] " + super.toString() + " | Peso: " + pesoKg + "kg";
    }

    public static Notebook lerDados(Scanner scanner) {
        System.out.print("ID: ");
        Integer id = Integer.parseInt(scanner.nextLine());
        System.out.print("Data de Cadastro (DD/MM/AAAA): ");
        String dataStr = scanner.nextLine();
        LocalDate data = LocalDate.parse(dataStr, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        System.out.print("Modelo (Ex: Acer Nitro V15): ");
        String modelo = scanner.nextLine();
        System.out.print("SO (1-WINDOWS, 2-MAC_OS, 3-LINUX): ");
        int soOp = Integer.parseInt(scanner.nextLine());
        SistemaOperacional so = SistemaOperacional.values()[soOp - 1];
        System.out.print("Peso em Kg (Ex: 2.1): ");
        Double peso = Double.parseDouble(scanner.nextLine());

        return new Notebook(id, data, modelo, so, peso);
    }
}
