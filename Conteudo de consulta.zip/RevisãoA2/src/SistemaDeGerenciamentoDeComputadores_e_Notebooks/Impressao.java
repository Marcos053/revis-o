package SistemaDeGerenciamentoDeComputadores_e_Notebooks;


public interface Impressao {
 void imprimir();
}