package SistemaDeGestãoDeProjetoDeSoftware;

public interface Imprimivel {
    void imprimirResumo();
}
