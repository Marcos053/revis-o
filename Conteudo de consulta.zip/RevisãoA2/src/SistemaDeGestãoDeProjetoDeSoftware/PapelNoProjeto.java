package SistemaDeGestãoDeProjetoDeSoftware;

public enum PapelNoProjeto {
    FRONTEND(1), BACKEND(2), DEVOPS(3), TECH_LEAD(4);
    
    private final int valor;
    
    PapelNoProjeto(int valor) { 
        this.valor = valor; 
    }
    
    public int getValor() { 
        return valor; 
    }
}
