package SistemaDeGestãoDeProjetoDeSoftware;

import java.util.Scanner;

public class Gerente extends Colaborador {
    private Integer anosExperiencia;

    public Gerente(Integer id, String nome, String email, Integer anosExperiencia) {
        super(id, nome, email);
        this.anosExperiencia = anosExperiencia;
    }

    public Integer getAnosExperiencia() { return anosExperiencia; }
    public void setAnosExperiencia(Integer anosExperiencia) { this.anosExperiencia = anosExperiencia; }

    @Override
    public void imprimirResumo() {
        System.out.println("[GERENTE] " + super.toString() + " | Experiência: " + anosExperiencia + " anos");
    }

    @Override
    public String toString() {
        return super.toString() + " | Cargo: Gerente";
    }

    public static Gerente lerDados(Scanner scanner) {
        System.out.print("ID: ");
        Integer id = Integer.parseInt(scanner.nextLine());
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("E-mail: ");
        String email = scanner.nextLine();
        
        Integer experiencia = 0;
        boolean valido = false;
        while (!valido) {
            try {
                System.out.print("Anos de Experiência: ");
                experiencia = Integer.parseInt(scanner.nextLine());
                valido = true;
            } catch (NumberFormatException e) {
                System.out.println("Erro: Por favor, digite um número inteiro válido para a experiência.");
            }
        }
        return new Gerente(id, nome, email, experiencia);
    }
}