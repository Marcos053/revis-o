package SistemaDeGestãoDeProjetoDeSoftware;

import java.util.Objects;
import java.util.Scanner;

public class Desenvolvedor extends Colaborador {
    private String linguagemPrincipal;

    public Desenvolvedor(Integer id, String nome, String email, String linguagemPrincipal) {
        super(id, nome, email);
        this.linguagemPrincipal = linguagemPrincipal;
    }

    public String getLinguagemPrincipal() { return linguagemPrincipal; }
    public void setLinguagemPrincipal(String linguagemPrincipal) { this.linguagemPrincipal = linguagemPrincipal; }

    @Override
    public void imprimirResumo() {
        System.out.println("[DEV] " + super.toString() + " | Linguagem: " + linguagemPrincipal);
    }

    @Override
    public String toString() {
        return super.toString() + " | Cargo: Desenvolvedor";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Desenvolvedor that = (Desenvolvedor) obj;
        return Objects.equals(this.getEmail(), that.getEmail());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getEmail());
    }

    public static Desenvolvedor lerDados(Scanner scanner) {
        System.out.print("ID: ");
        Integer id = Integer.parseInt(scanner.nextLine());
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("E-mail: ");
        String email = scanner.nextLine();
        System.out.print("Linguagem Principal: ");
        String linguagem = scanner.nextLine();
        return new Desenvolvedor(id, nome, email, linguagem);
    }
}