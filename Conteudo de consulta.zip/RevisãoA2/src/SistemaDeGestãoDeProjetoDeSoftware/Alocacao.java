package SistemaDeGestãoDeProjetoDeSoftware;

public class Alocacao {
    private PapelNoProjeto papel;
    private Desenvolvedor desenvolvedor;

    public Alocacao(PapelNoProjeto papel, Desenvolvedor desenvolvedor) {
        this.papel = papel;
        this.desenvolvedor = desenvolvedor;
    }

    public PapelNoProjeto getPapel() { return papel; }
    public Desenvolvedor getDesenvolvedor() { return desenvolvedor; }

    @Override
    public String toString() {
        return desenvolvedor.getNome() + " atua como " + papel.name();
    }
}