package SistemaDeGestãoDeProjetoDeSoftware;

public enum StatusProjeto {
    PLANEJAMENTO(1), EM_ANDAMENTO(2), CONCLUIDO(3);
    
    private final int valor;
    
    StatusProjeto(int valor) { 
        this.valor = valor; 
    }
    
    public int getValor() { 
        return valor; 
    }
}
