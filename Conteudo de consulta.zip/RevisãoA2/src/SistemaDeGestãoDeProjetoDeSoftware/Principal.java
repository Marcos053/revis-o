package SistemaDeGestãoDeProjetoDeSoftware;

import java.time.LocalDate;
import java.util.*;

public class Principal {
    private static List<Colaborador> colaboradores = new ArrayList<>();
    private static Map<Integer, Projeto> projetos = new HashMap<>(); 
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcao = -1;
        while (opcao != 6) { 
            System.out.println("\n=== SISTEMA DE GESTÃO DE PROJETOS ===");
            System.out.println("1. Inserir Colaborador");
            System.out.println("2. Inserir Projeto");
            System.out.println("3. Listar Todos os Colaboradores");
            System.out.println("4. Listar Projetos");
            System.out.println("5. Listar Desenvolvedores de um Projeto");
            System.out.println("6. Sair");
            System.out.print("Escolha uma opção: ");
            
            try {
                opcao = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Opção inválida.");
                continue;
            }

            switch (opcao) {
                case 1: inserirColaborador(); break;
                case 2: inserirProjeto(); break;
                case 3: imprimirColaboradores(); break;
                case 4: imprimirProjetos(); break;
                case 5: listarDevsPorProjeto(); break;
                case 6: System.out.println("Saindo do sistema..."); break;
                default: System.out.println("Opção inválida!");
            }
        }
    }

    private static void inserirColaborador() {
        System.out.println("\n--- CADASTRAR COLABORADOR ---");
        System.out.println("1 - Desenvolvedor | 2 - Gerente");
        System.out.print("Opção: ");
        String tipo = scanner.nextLine();

        try {
            if (tipo.equals("1")) {
                Desenvolvedor dev = Desenvolvedor.lerDados(scanner);
                colaboradores.add(dev);
                System.out.println("Desenvolvedor cadastrado com sucesso!");
            } else if (tipo.equals("2")) {
                Gerente ger = Gerente.lerDados(scanner);
                colaboradores.add(ger);
                System.out.println("Gerente cadastrado com sucesso!");
            } else {
                System.out.println("Tipo inválido.");
            }
        } catch (Exception e) {
            System.out.println("Erro ao cadastrar: Verifique os dados digitados.");
        }
    }

    private static void inserirProjeto() {
        System.out.println("\n--- CADASTRAR PROJETO ---");
        try {
            System.out.print("ID do Projeto: ");
            Integer id = Integer.parseInt(scanner.nextLine());
            System.out.print("Título: ");
            String titulo = scanner.nextLine();
            
            System.out.println("Selecione o Status (1-PLANEJAMENTO, 2-EM ANDAMENTO, 3-CONCLUIDO): ");
            int statusOp = Integer.parseInt(scanner.nextLine());
            StatusProjeto status = StatusProjeto.values()[statusOp - 1];

            System.out.println("--- Escolha o Gerente Responsável pelo ID ---");
            colaboradores.stream()
                .filter(c -> c instanceof Gerente)
                .forEach(c -> c.imprimirResumo());
            
            System.out.print("ID do Gerente: ");
            Integer idGerente = Integer.parseInt(scanner.nextLine());
            
            Gerente gerenteResp = (Gerente) colaboradores.stream()
                .filter(c -> c instanceof Gerente && c.getId().equals(idGerente))
                .findFirst().orElse(null);

            if (gerenteResp == null) {
                System.out.println("Gerente não encontrado. Projeto não criado.");
                return;
            }

            Projeto projeto = new Projeto(id, titulo, LocalDate.now(), status, gerenteResp);

            String continuar = "s";
            while (continuar.equalsIgnoreCase("s")) {
                System.out.println("--- Alocar Desenvolvedor ---");
                colaboradores.stream()
                    .filter(c -> c instanceof Desenvolvedor)
                    .forEach(c -> c.imprimirResumo());
                
                System.out.print("ID do Desenvolvedor: ");
                Integer idDev = Integer.parseInt(scanner.nextLine());
                
                Desenvolvedor dev = (Desenvolvedor) colaboradores.stream()
                    .filter(c -> c instanceof Desenvolvedor && c.getId().equals(idDev))
                    .findFirst().orElse(null);

                if (dev != null) {
                    System.out.println("Papel (1-FRONTEND, 2-BACKEND, 3-DEVOPS, 4-TECH_LEAD): ");
                    int papelOp = Integer.parseInt(scanner.nextLine());
                    PapelNoProjeto papel = PapelNoProjeto.values()[papelOp - 1];
                    
                    projeto.adicionarAlocacao(new Alocacao(papel, dev));
                    System.out.println("Desenvolvedor alocado!");
                } else {
                    System.out.println("Desenvolvedor não encontrado.");
                }

                System.out.print("Deseja alocar outro desenvolvedor? (s/n): ");
                continuar = scanner.nextLine();
            }

            projetos.put(projeto.getId(), projeto); 
            System.out.println("Projeto salvo com sucesso!");

        } catch (Exception e) {
            System.out.println("Erro ao cadastrar o projeto. Operação cancelada.");
        }
    }

    private static void imprimirColaboradores() {
        System.out.println("\n--- LISTA DE COLABORADORES ---");
        
        System.out.println("\n>> GERENTES:");
        colaboradores.stream()
            .filter(c -> c instanceof Gerente)
            .sorted((c1, c2) -> c1.getNome().compareToIgnoreCase(c2.getNome())) 
            .forEach(Colaborador::imprimirResumo);

        System.out.println("\n>> DESENVOLVEDORES:");
        colaboradores.stream()
            .filter(c -> c instanceof Desenvolvedor)
            .sorted(Comparator.comparing(Colaborador::getNome)) 
            .forEach(Colaborador::imprimirResumo);
    }

    private static void imprimirProjetos() {
        System.out.println("\n--- LISTA DE PROJETOS ---");
        if (projetos.isEmpty()) {
            System.out.println("Nenhum projeto cadastrado.");
            return;
        }
        for (Projeto p : projetos.values()) { 
            p.imprimirResumo();
            System.out.println("-------------------------");
        }
    }

    private static void listarDevsPorProjeto() {
        System.out.print("\nDigite o ID do Projeto: ");
        try {
            Integer idProj = Integer.parseInt(scanner.nextLine());
            Projeto proj = projetos.get(idProj); 

            if (proj != null) {
                System.out.println("\n--- ALOCAÇÕES DO PROJETO: " + proj.getTitulo() + " ---");
                List<Alocacao> alocacoes = proj.getAlocacoes();
                
                alocacoes.sort((a1, a2) -> a1.getPapel().compareTo(a2.getPapel()));
                
                for (Alocacao a : alocacoes) {
                    System.out.println(a.getPapel() + " -> " + a.getDesenvolvedor().getNome());
                }
            } else {
                System.out.println("Projeto não encontrado no sistema.");
            }
        } catch (NumberFormatException e) {
            System.out.println("ID inválido.");
        }
    }
}
