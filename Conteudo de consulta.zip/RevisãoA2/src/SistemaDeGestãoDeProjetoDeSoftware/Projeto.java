package SistemaDeGestãoDeProjetoDeSoftware;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Projeto implements Imprimivel {
    private Integer id;
    private String titulo;
    private LocalDate dataInicio;
    private StatusProjeto status;
    private Gerente gerenteResponsavel;
    private List<Alocacao> alocacoes;

    public Projeto(Integer id, String titulo, LocalDate dataInicio, StatusProjeto status, Gerente gerenteResponsavel) {
        this.id = id;
        this.titulo = titulo;
        this.dataInicio = dataInicio;
        this.status = status;
        this.gerenteResponsavel = gerenteResponsavel;
        this.alocacoes = new ArrayList<>();
    }

    public Integer getId() { return id; }
    public String getTitulo() { return titulo; }
    public List<Alocacao> getAlocacoes() { return alocacoes; }
    public void adicionarAlocacao(Alocacao alocacao) { this.alocacoes.add(alocacao); }

    @Override
    public void imprimirResumo() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        System.out.println("--- PROJETO: " + titulo + " ---");
        System.out.println("ID: " + id + " | Status: " + status + " | Início: " + dataInicio.format(fmt));
        System.out.println("Gerente Responsável: " + (gerenteResponsavel != null ? gerenteResponsavel.getNome() : "Nenhum"));
        System.out.println("Total de Devs Alocados: " + alocacoes.size());
    }

    @Override
    public String toString() {
        return "Projeto{" + "id=" + id + ", titulo='" + titulo + '\'' + '}';
    }
}
