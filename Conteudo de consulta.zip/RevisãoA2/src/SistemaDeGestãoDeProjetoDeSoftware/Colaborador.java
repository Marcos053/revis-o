package SistemaDeGestãoDeProjetoDeSoftware;

public abstract class Colaborador implements Imprimivel {
    private Integer id;
    private String nome;
    private String email;

    public Colaborador(Integer id, String nome, String email) {
        this.id = id;
        this.nome = nome;
        this.email = email;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    @Override
    public String toString() {
        return "ID: " + id + " | Nome: " + nome + " | E-mail: " + email;
    }
}
