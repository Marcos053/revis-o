package E_commerce;

public class Item {
    private Integer quantidade; // [cite: 744]
    private Double valor; // [cite: 744]
    private Produto produto; // Relacionamento [cite: 746]

    public Item(Integer quantidade, Double valor, Produto produto) {
        this.quantidade = quantidade;
        this.valor = valor;
        this.produto = produto;
    }

    // Métodos de acesso exigidos [cite: 715]
    public Integer getQuantidade() { return quantidade; }
    public void setQuantidade(Integer quantidade) { this.quantidade = quantidade; }
    public Double getValor() { return valor; }
    public void setValor(Double valor) { this.valor = valor; }
    public Produto getProduto() { return produto; }
    public void setProduto(Produto produto) { this.produto = produto; }

    @Override
    public String toString() { // [cite: 735]
        return produto.getNome() + " | Qtde: " + quantidade + " | Valor Unit: R$ " + valor + " | Subtotal: R$ " + (quantidade * valor);
    }
}
