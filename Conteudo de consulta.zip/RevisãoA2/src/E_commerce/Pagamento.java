package E_commerce;

public class Pagamento {
    private Double valor; // [cite: 758]
    private TipoPagamento tipoPagamento; // Relacionamento [cite: 757, 759]

    public Pagamento(Double valor, TipoPagamento tipoPagamento) {
        this.valor = valor;
        this.tipoPagamento = tipoPagamento;
    }

    public Double getValor() { return valor; }
    public void setValor(Double valor) { this.valor = valor; }
    public TipoPagamento getTipoPagamento() { return tipoPagamento; }
    public void setTipoPagamento(TipoPagamento tipoPagamento) { this.tipoPagamento = tipoPagamento; }
}
