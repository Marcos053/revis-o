package E_commerce;

import java.util.List;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Pedido pedido = new Pedido();
        List<Produto> catalogo = Produto.getProdutos(); // [cite: 716]

        int opcao = -1;
        while (opcao != 5) { // Menu infinito [cite: 728]
            System.out.println("\n=== E-COMMERCE ===");
            System.out.println("1. Inserir um Produto no Pedido"); // [cite: 729]
            System.out.println("2. Alterar a quantidade do item do Pedido"); // 
            System.out.println("3. Listar Todos os Itens"); // [cite: 731]
            System.out.println("4. Finalizar a Compra"); // [cite: 732]
            System.out.println("5. Sair"); // [cite: 733]
            System.out.print("Escolha: ");
            
            try {
                opcao = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Digite apenas números.");
                continue;
            }

            switch (opcao) {
                case 1: // [cite: 729]
                    System.out.println("\n--- PRODUTOS DISPONÍVEIS ---");
                    catalogo.forEach(p -> System.out.println(p.toString())); // [cite: 718]
                    
                    System.out.print("\nDigite o ID do produto para adicionar: ");
                    int idAdd = Integer.parseInt(scanner.nextLine());
                    
                    Produto prodEncontrado = catalogo.stream().filter(p -> p.getId() == idAdd).findFirst().orElse(null);
                    if (prodEncontrado != null) {
                        pedido.adicionar(prodEncontrado); // [cite: 718, 739]
                    } else {
                        System.out.println("Produto não encontrado.");
                    }
                    break;

                case 2: // 
                    if (pedido.getItens().isEmpty()) {
                        System.out.println("O carrinho está vazio.");
                        break;
                    }
                    
                    System.out.println("\n--- ITENS NO CARRINHO ---");
                    pedido.listarTodosItens(); // [cite: 719]
                    
                    System.out.print("\nDigite o ID do produto que deseja alterar a quantidade: ");
                    int idAlt = Integer.parseInt(scanner.nextLine());
                    
                    Item itemParaAlterar = pedido.getItens().stream()
                        .filter(i -> i.getProduto().getId() == idAlt)
                        .findFirst().orElse(null);
                        
                    if (itemParaAlterar != null) {
                        System.out.print("Digite a nova quantidade: ");
                        int novaQtd = Integer.parseInt(scanner.nextLine());
                        pedido.alterarQuantidade(itemParaAlterar, novaQtd); // [cite: 719, 740]
                        System.out.println("Quantidade atualizada!");
                    } else {
                        System.out.println("Produto não está no carrinho.");
                    }
                    break;

                case 3: // [cite: 731]
                    System.out.println("\n--- CARRINHO ---");
                    pedido.listarTodosItens(); // [cite: 741]
                    break;

                case 4: // [cite: 732]
                    if (pedido.getItens().isEmpty()) {
                        System.out.println("Não é possível finalizar um pedido vazio.");
                        break;
                    }

                    // Preenchendo dados exigidos [cite: 723]
                    System.out.println("\n--- DADOS DO CLIENTE ---");
                    System.out.print("Nome: ");
                    pedido.setNomeCliente(scanner.nextLine());
                    System.out.print("CPF: ");
                    pedido.setCpfCliente(scanner.nextLine());
                    System.out.print("E-mail: ");
                    pedido.setEmailCliente(scanner.nextLine());

                    System.out.println("\nTotal da Compra: R$ " + String.format("%.2f", pedido.totalCompra()));
                    System.out.println("Forma de Pagamento (1-Crédito, 2-Débito, 3-PIX): ");
                    int pgtoOp = Integer.parseInt(scanner.nextLine());
                    TipoPagamento tp = TipoPagamento.values()[pgtoOp - 1]; // [cite: 759]
                    
                    pedido.setPagamento(new Pagamento(pedido.totalCompra(), tp)); // [cite: 756]
                    
                    pedido.finalizarCompra(); // [cite: 723, 755]
                    break;

                case 5: // [cite: 733]
                    System.out.println("Encerrando o sistema...");
                    break;

                default:
                    System.out.println("Opção inválida!");
            }
        }
        scanner.close();
    }
}