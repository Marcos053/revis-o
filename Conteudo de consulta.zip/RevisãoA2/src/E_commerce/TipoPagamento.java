package E_commerce;

public enum TipoPagamento {
    CARTAO_CREDITO(1), // [cite: 760]
    CARTAO_DEBITO(2), // [cite: 760]
    PIX(3); // [cite: 760]
    
    private final int valor;
    
    TipoPagamento(int valor) { 
        this.valor = valor; 
    }
    
    public int getValor() { 
        return valor; 
    }
}
