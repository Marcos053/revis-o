package E_commerce;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Pedido implements Controlador {
    private LocalDateTime dataCompra; // [cite: 752]
    private String cpfCliente; // [cite: 752]
    private String nomeCliente; // [cite: 753]
    private String emailCliente; // [cite: 754]
    private List<Item> itens = new ArrayList<>(); // Relacionamento [cite: 746]
    private Pagamento pagamento; // Relacionamento [cite: 756]

    // Métodos de acesso [cite: 715]
    public LocalDateTime getDataCompra() { return dataCompra; }
    public void setDataCompra(LocalDateTime dataCompra) { this.dataCompra = dataCompra; }
    public String getCpfCliente() { return cpfCliente; }
    public void setCpfCliente(String cpfCliente) { this.cpfCliente = cpfCliente; }
    public String getNomeCliente() { return nomeCliente; }
    public void setNomeCliente(String nomeCliente) { this.nomeCliente = nomeCliente; }
    public String getEmailCliente() { return emailCliente; }
    public void setEmailCliente(String emailCliente) { this.emailCliente = emailCliente; }
    public List<Item> getItens() { return itens; }
    public Pagamento getPagamento() { return pagamento; }
    public void setPagamento(Pagamento pagamento) { this.pagamento = pagamento; }

    @Override
    public void adicionar(Produto produto) { // 
        // Requisito C.1: Define quantidade inicial como 1, copiando o valor do produto
        Item novoItem = new Item(1, produto.getPreco(), produto); // [cite: 718]
        itens.add(novoItem);
        System.out.println("Produto adicionado! (Quantidade inicial: 1). Use a opção do menu para alterar a quantidade.");
    }

    @Override
    public void alterarQuantidade(Item item, int novaQtde) { // [cite: 740]
        item.setQuantidade(novaQtde); // [cite: 719]
    }

    @Override
    public void listarTodosItens() { // [cite: 741]
        if (itens.isEmpty()) {
            System.out.println("Nenhum item no pedido.");
            return;
        }
        // Requisito D.1: Ordenado pelo ID do produto [cite: 721]
        itens.stream()
            .sorted(Comparator.comparing(item -> item.getProduto().getId()))
            .forEach(item -> System.out.println(item.toString()));
    }

    @Override
    public List<Item> buscarItensSemEstoque() { // [cite: 742]
        // Requisito D.2: Filtra itens onde estoque < quantidade [cite: 722]
        return itens.stream()
            .filter(item -> item.getProduto().getEstoque() < item.getQuantidade())
            .collect(Collectors.toList());
    }

    public Double totalCompra() { // [cite: 755]
        return itens.stream()
            .mapToDouble(item -> item.getValor() * item.getQuantidade())
            .sum();
    }

    public void finalizarCompra() { // [cite: 755]
        List<Item> itensSemEstoque = buscarItensSemEstoque(); // [cite: 724]
        
        if (!itensSemEstoque.isEmpty()) { // Validação de estoque [cite: 724]
            System.out.println("\n[ERRO] Não é possível finalizar a compra. Itens sem estoque suficiente:");
            itensSemEstoque.forEach(item -> System.out.println(" - " + item.getProduto().getNome() + " (Estoque atual: " + item.getProduto().getEstoque() + ")"));
            return;
        }

        this.dataCompra = LocalDateTime.now(); // [cite: 752]
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

        // Requisito E: Impressão final [cite: 725]
        System.out.println("\n===== COMPRA FINALIZADA COM SUCESSO =====");
        System.out.println("Cliente: " + nomeCliente); // [cite: 725]
        System.out.println("Data da Compra: " + dataCompra.format(fmt)); // [cite: 725]
        System.out.println("Total Pago: R$ " + String.format("%.2f", totalCompra())); // [cite: 725]
        
        // Deduzindo o estoque (ação implícita após confirmação)
        for(Item i : itens) {
            i.getProduto().setEstoque(i.getProduto().getEstoque() - i.getQuantidade());
        }
        
        // Limpando o carrinho para a próxima compra
        itens.clear(); 
    }
}
