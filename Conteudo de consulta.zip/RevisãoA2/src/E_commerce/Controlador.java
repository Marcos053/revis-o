package E_commerce;

import java.util.List;

public interface Controlador {
    void adicionar(Produto produto); //
    void alterarQuantidade(Item item, int novaQtde); //
    void listarTodosItens(); //
    List<Item> buscarItensSemEstoque(); //
}
