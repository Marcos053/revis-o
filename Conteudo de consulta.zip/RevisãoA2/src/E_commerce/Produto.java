package E_commerce;

import java.util.ArrayList;
import java.util.List;

public class Produto {
	private int id; // [cite: 747]
	private String nome; // [cite: 748]
	private String descricao; // [cite: 749]
	private Double preco; // [cite: 749]
	private Integer estoque; // [cite: 749]

	public Produto(int id, String nome, String descricao, Double preco, Integer estoque) {
		this.id = id;
		this.nome = nome;
		this.descricao = descricao;
		this.preco = preco;
		this.estoque = estoque;
	}

	// Métodos de acesso exigidos [cite: 715]
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Double getPreco() {
		return preco;
	}

	public void setPreco(Double preco) {
		this.preco = preco;
	}

	public Integer getEstoque() {
		return estoque;
	}

	public void setEstoque(Integer estoque) {
		this.estoque = estoque;
	}

	@Override
	public boolean equals(Object obj) { // [cite: 736]
		if (this == obj)
			return true;
		if (obj == null || getClass() != obj.getClass())
			return false;
		Produto produto = (Produto) obj;
		return id == produto.id;
	}

	@Override
	public String toString() { // [cite: 735]
		return "ID: " + id + " | " + nome + " (" + descricao + ") | R$ " + preco + " | Estoque: " + estoque;
	}

	// Requisito B: Método estático com no mínimo 6 produtos [cite: 716]
	public static List<Produto> getProdutos() { // [cite: 750]
		List<Produto> catalogo = new ArrayList<>();
		catalogo.add(new Produto(1, "Notebook", "16GB RAM, SSD 512GB", 3500.0, 10));
		catalogo.add(new Produto(2, "Smartphone", "128GB, Câmera 50MP", 2000.0, 5));
		catalogo.add(new Produto(3, "Monitor", "24 Polegadas IPS", 800.0, 20));
		catalogo.add(new Produto(4, "Teclado Mecânico", "Switch Azul", 250.0, 15));
		catalogo.add(new Produto(5, "Mouse Gamer", "RGB 10000 DPI", 150.0, 0)); // Teste de falta de estoque
		catalogo.add(new Produto(6, "Headset", "Som Surround 7.1", 300.0, 8));
		return catalogo;
	}
}
