package Atividade;

public interface InterRadio {
 void ligar();
 void desligar();
 void mudarEstacao(float valor);
}
