package Atividade;

//Relogio.java
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class Relogio implements InterRelogio {
 private LocalTime tempo;


 public Relogio() {
     this.tempo = LocalTime.now();
 }

 @Override
 public int getHoras() {
     return this.tempo.getHour();
 }

 @Override
 public int getMinutos() {
     return this.tempo.getMinute();
 }

 @Override
 public int getSegundos() {
     return this.tempo.getSecond();
 }

 @Override
 public String getHoraCompleta() {
     DateTimeFormatter formatador = DateTimeFormatter.ofPattern("HH:mm:ss");
     return this.tempo.format(formatador);
 }


 public void setTempo(LocalTime tempo) {
     this.tempo = tempo;
 }
}