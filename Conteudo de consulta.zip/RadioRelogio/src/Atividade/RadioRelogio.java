package Atividade;


import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class RadioRelogio implements InterRadio, InterRelogio {
	private float estacao;
	private boolean ligado;
	private LocalTime tempo;

	public RadioRelogio() {
		this.estacao = 87.5f;
		this.ligado = false;
		this.tempo = LocalTime.now();
	}

	@Override
	public void ligar() {
		this.ligado = true;
		System.out.println("Rádio-Relógio: Rádio ativado.");
	}

	@Override
	public void desligar() {
		this.ligado = false;
		System.out.println("Rádio-Relógio: Rádio desativado.");
	}

	@Override
	public void mudarEstacao(float valor) {
		if (this.ligado) {
			this.estacao = valor;
			System.out.println("Rádio-Relógio: Sintonizado na estação " + this.estacao + " FM");
		} else {
			System.out.println("Rádio-Relógio: Ligue o rádio primeiro para mudar de estação.");
		}
	}

	@Override
	public int getHoras() {
		return this.tempo.getHour();
	}

	@Override
	public int getMinutos() {
		return this.tempo.getMinute();
	}

	@Override
	public int getSegundos() {
		return this.tempo.getSecond();
	}

	@Override
	public String getHoraCompleta() {
		DateTimeFormatter formatador = DateTimeFormatter.ofPattern("HH:mm:ss");
		return this.tempo.format(formatador);
	}

	public static void main(String[] adjournment) {
		System.out.println("--- Testando o Rádio ---");
		Radio meuRadio = new Radio();
		meuRadio.ligar();
		meuRadio.mudarEstacao(94.9f);
		meuRadio.desligar();

		System.out.println("\n--- Testando o Relógio ---");
		Relogio meuRelogio = new Relogio();
		System.out.println("Hora atual: " + meuRelogio.getHoraCompleta());

		System.out.println("\n--- Testando o Rádio-Relógio ---");
		RadioRelogio meuRadioRelogio = new RadioRelogio();
		System.out.println("Horas no visor: " + meuRadioRelogio.getHoraCompleta());
		meuRadioRelogio.ligar();
		meuRadioRelogio.mudarEstacao(100.1f);
	}

}
