package Atividade;

public interface InterRelogio {
 int getHoras();
 int getMinutos();
 int getSegundos();
 String getHoraCompleta();
}
