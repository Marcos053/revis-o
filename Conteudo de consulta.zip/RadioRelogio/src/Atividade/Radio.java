package Atividade;

//Radio.java
public class Radio implements InterRadio {
	private float estacao;
	private boolean ligado;

	public Radio() {
		this.estacao = 87.5f;
		this.ligado = false;
	}

	@Override
	public void ligar() {
		this.ligado = true;
		System.out.println("Rádio ligado.");
	}

	@Override
	public void desligar() {
		this.ligado = false;
		System.out.println("Rádio desligado.");
	}

	@Override
	public void mudarEstacao(float valor) {
		if (this.ligado) {
			this.estacao = valor;
			System.out.println("Estação mudada para: " + this.estacao + " FM");
		} else {
			System.out.println("Não é possível mudar de estação. O rádio está desligado.");
		}
	}

	public float getEstacao() {
		return estacao;
	}

	public boolean isLigado() {
		return ligado;
	}
}
