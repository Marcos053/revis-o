package app;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import modelo.Pessoa;

public class Principal  {
	
	public static void main(String[] args) {
		
		Integer numero = 10;
		
		System.out.println(numero.compareTo(5));
		System.out.println(numero.compareTo(10));
		System.out.println(numero.compareTo(13));
		
		
		List<Pessoa> lista = new ArrayList<Pessoa>();
		lista.add(new Pessoa ("111", "Leandra",39));
		lista.add(new Pessoa ("444", "Marco",41));
		lista.add(new Pessoa ("333", "Carlos Miguel",38));
		lista.add(new Pessoa ("111", "Silvano",45));
		lista.add(new Pessoa ("111", "Alex",40));
//		lista.add("Vini");
//		lista.add("Enzo");
//		lista.add("Maria");
//		lista.add("Ana");
//		lista.add("Janio");
		
	for (Pessoa pessoa : lista) {
		System.out.println(pessoa);
	}
	//	Collections.sort(lista);
		
		System.out.println();
		for (Pessoa pessoa : lista) {
			System.out.println(pessoa);
		}
	}
}