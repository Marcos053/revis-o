package principal;

import java.util.Scanner;
import modelo.Aula;

public class Principal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Aula[] aulas = new Aula[10]; 
        int opcao = 0;
        int indice = 0;

        while (opcao != 3) {
            System.out.println("\n*** MENU ***");
            System.out.println("1) Adicionar Aula");
            System.out.println("2) Pesquisar por Especialidade");
            System.out.println("3) Sair");
            System.out.print("Opção: ");
            opcao = Integer.parseInt(sc.nextLine());

            if (opcao == 1) {
                if (indice < 10) {
                    aulas[indice++] = Aula.lerDadosAula();
                    System.out.println("Aula cadastrada com sucesso!");
                } else {
                    System.out.println("Limite de aulas atingido!");
                }
            } else if (opcao == 2) {
                System.out.print("Digite a especialidade para busca: ");
                String esp = sc.nextLine();
                Aula[] resultados = Aula.pesquisar(aulas, esp);
                
                System.out.println("\n--- Resultados da Pesquisa ---");
                boolean encontrou = false;
                for (Aula r : resultados) {
                    if (r != null) {
                        r.exibirInfo("ENCONTRADO"); 
                        encontrou = true;
                    }
                }
                if (!encontrou) System.out.println("Nenhuma aula encontrada para esta especialidade.");
            }
        }
        System.out.println("Encerrando sistema...");
        sc.close();
    }
}