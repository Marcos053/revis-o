package modelo;

import java.util.Scanner;

public class Sensei {
    private String nome;
    private int idade;
    private String especialidade; 

    public Sensei(String nome, int idade, String especialidade) {
        this.nome = nome;
        this.idade = idade;
        this.especialidade = especialidade;
    }

    public static Sensei lerDadosSensei() {
        Scanner sc = new Scanner(System.in);
        System.out.println("--- Cadastro de Sensei ---");
        System.out.print("Nome: ");
        String nome = sc.nextLine();
        System.out.print("Idade: ");
        int idade = Integer.parseInt(sc.nextLine());
        System.out.print("Especialidade: ");
        String especialidade = sc.nextLine();
        return new Sensei(nome, idade, especialidade);
    }

    public void exibirInfo() {
        System.out.println(this.toString());
    }

    @Override
    public String toString() {
        return "Sensei: " + nome + " | Idade: " + idade + " | Especialidade: " + especialidade;
    }

    // Getters e Setters
    public String getEspecialidade() { return especialidade; }
    public String getNome() { return nome; }
}
