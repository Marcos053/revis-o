package modelo;

import java.util.Scanner;

public class Aula {
    private String nomeAula;
    private int duracaoMinutos;
    private String sala;
    private Sensei[] senseis; 

    public Aula(String nomeAula, int duracaoMinutos, String sala) {
        this.nomeAula = nomeAula;
        this.duracaoMinutos = duracaoMinutos;
        this.sala = sala;
        this.senseis = new Sensei[2]; 
    }

    public static Aula lerDadosAula() {
        Scanner sc = new Scanner(System.in);
        System.out.println("\n--- Cadastro de Aula ---");
        System.out.print("Nome da Aula: ");
        String nome = sc.nextLine();
        System.out.print("Duração (min): ");
        int duracao = Integer.parseInt(sc.nextLine());
        System.out.print("Sala: ");
        String sala = sc.nextLine();

        Aula aula = new Aula(nome, duracao, sala);
        
        System.out.print("Quantos senseis para esta aula? (1 ou 2): ");
        int qtd = Integer.parseInt(sc.nextLine());
        for (int i = 0; i < qtd && i < 2; i++) {
            aula.senseis[i] = Sensei.lerDadosSensei();
        }
        return aula;
    }

   
    public void exibirInfo() {
        System.out.println(this.toString());
    }

    public void exibirInfo(String prefixo) {
        System.out.println(prefixo + ": " + this.nomeAula);
        this.exibirInfo();
    }

    @Override
    public String toString() {
        String infoSenseis = "";
        for (Sensei s : senseis) {
            if (s != null) infoSenseis += "\n  -> " + s.toString();
        }
        return "Aula: " + nomeAula + " | Duração: " + duracaoMinutos + "min | Sala: " + sala + infoSenseis;
    }

   
    public static Aula[] pesquisar(Aula[] aulas, String especialidade) {
        Aula[] resultados = new Aula[aulas.length];
        int cont = 0;
        for (Aula a : aulas) {
            if (a != null) {
                for (Sensei s : a.senseis) {
                    if (s != null && s.getEspecialidade().equalsIgnoreCase(especialidade)) {
                        resultados[cont++] = a;
                        break; 
                    }
                }
            }
        }
        return resultados;
    }
}