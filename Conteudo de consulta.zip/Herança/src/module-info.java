module Herança {
}