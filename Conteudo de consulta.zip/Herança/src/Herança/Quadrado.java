package Herança;

public class Quadrado extends Retangulo{
	
	public Quadrado(int tamanho) {
		super(tamanho, tamanho);
		
	}

	public void setTamanho(int tamanho){
	this.altura = tamanho;
	this.largura = tamanho;

}
}
