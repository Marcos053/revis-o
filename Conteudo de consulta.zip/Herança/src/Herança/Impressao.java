package Herança;

public interface Impressao {
	public void imprimir();
}