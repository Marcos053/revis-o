package Herança;

import java.util.Objects;

public  class Retangulo {
	

	public Retangulo(int altura, int largura) {
		this.altura = altura;
		this.largura = largura;
	}
	
	public  void imprimir() {
		System.out.println("Retangulo");
		System.out.println("Altura: " + this.getAltura());
		System.out.println("Largura: "+ this.getLargura());
	}
	
	protected int altura;
	protected int largura;
	public int getAltura() {
		return altura;
	}
	private void setAltura(int altura) {
		this.altura = altura;
	}
	public int getLargura() {
		return largura;
	}
	private void setLargura(int largura) {
		this.largura = largura;
	}

	@Override
	public int hashCode() {
		return Objects.hash(altura, largura);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Retangulo other = (Retangulo) obj;
		return altura == other.altura && largura == other.largura;
	}

}
