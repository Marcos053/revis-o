package Herança;

public class PessoaFisica extends Pessoa implements Impressao {
	public String cpf;

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
    @Override
	public void imprimir() {
		System.out.println("cpf:" + getCpf());
		System.out.println("nome:" + getNome());
		
	}
}
