package Herança;

public abstract class Pessoa implements Impressao  {

	public String nome;
	
	
	
	public String getNome() {
		return nome;
	}



	public void setNome(String nome) {
		this.nome = nome;
	}




}
