package App;
import java.util.ArrayList;
import java.util.List;

import Herança.Impressao;
import Herança.PessoaFisica;



public class Principal {

	public static void main(String[] args) {

	List<String> l = new ArrayList<String>();
	l.add("I WILL MAKE");
	l.add("YOU SAY");
	l.add("HOW PROUD");
	l.add("YOU ARE OF ME");
	//l.add(Boolean.FALSE);
	
	System.out.println(l.size());
	System.out.println("Esta vazia? "+ l.isEmpty());
	l.remove(1);
	
	for (Object obj: l) {
		System.out.println(obj);
	}
		
		
		
		
		
		
		
		
		
//		PessoaFisica pf = new PessoaFisica();
	//
		//pf.setNome("Leanda");
		//pf.setCpf("79823729249801");
		
		//Impressao x = pf;
		//x.imprimir();
		
//		pf.imprimir();

	}
	
	public static void imprimir( Impressao i) {
		i.imprimir();
	}
}
	
//	public static void imprimir(Quadrado quadrado) {
//		System.out.println("Quadrado");
//		System.out.println(quadrado.getAltura());
//		System.out.println(quadrado.getLargura());
//	}
//	public static void imprimir(Retangulo retangulo) {
//		System.out.println("Retangulo");
//		System.out.println(retangulo.getAltura());
//		System.out.println(retangulo.getLargura());
//	}
//}
