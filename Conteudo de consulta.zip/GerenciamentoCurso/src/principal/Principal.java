package principal;

import java.util.Scanner;
import modelo.Curso; 

public class Principal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Curso[] cursos = new Curso[10]; 
        int totalCursos = 0;
        int opcao = 0;

        while (opcao != 3) {
            System.out.println("\n--- SISTEMA DE CURSOS ---");
            System.out.println("1) Adicionar Curso");
            System.out.println("2) Pesquisar por Categoria");
            System.out.println("3) Sair");
            System.out.print("Escolha: ");
            opcao = Integer.parseInt(sc.nextLine());

            if (opcao == 1) {
                if (totalCursos < 10) {
                    cursos[totalCursos++] = Curso.lerDadosCurso();
                } else {
                    System.out.println("Capacidade máxima atingida!");
                }
            } else if (opcao == 2) {
                System.out.print("Digite a categoria: ");
                String busca = sc.nextLine();
                Curso[] encontrados = Curso.pesquisar(cursos, busca);
                
                System.out.println("\n--- RESULTADOS ---");
                for (Curso c : encontrados) {
                    if (c != null) c.exibirInfo("FILTRO ATIVO"); 
                }
            }
        }
        sc.close();
    }
}
