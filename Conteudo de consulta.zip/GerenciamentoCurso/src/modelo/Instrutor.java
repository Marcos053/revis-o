package modelo;

import java.util.Scanner;

public class Instrutor {
    private String nome;
    private String cpf;
    private String formacao;
    private int anosExperiencia;

    public Instrutor(String nome, String cpf, String formacao, int anosExperiencia) {
        this.nome = nome;
        this.cpf = cpf;
        this.formacao = formacao;
        this.anosExperiencia = anosExperiencia;
    }

    public static Instrutor lerDadosInstrutor() {
        Scanner sc = new Scanner(System.in);
        System.out.println("--- Cadastro de Instrutor ---");
        System.out.print("Nome: ");
        String nome = sc.nextLine();
        System.out.print("CPF: ");
        String cpf = sc.nextLine();
        System.out.print("Formação: ");
        String form = sc.nextLine();
        System.out.print("Anos de Experiência: ");
        int anos = Integer.parseInt(sc.nextLine());
        return new Instrutor(nome, cpf, form, anos);
    }

    public void exibirInfo() {
        System.out.println(this.toString());
    }

    @Override
    public String toString() {
        return "Instrutor: " + nome + " | Formação: " + formacao + " | Exp: " + anosExperiencia + " anos";
    }
}