package modelo;

import java.util.Scanner;

public class Curso {
    private String titulo;
    private int cargaHoraria;
    private double valor;
    private String categoria; 
    private Instrutor[] instrutores;

    public Curso(String titulo, int cargaHoraria, double valor, String categoria) {
        this.titulo = titulo;
        this.cargaHoraria = cargaHoraria;
        this.valor = valor;
        this.categoria = categoria;
        this.instrutores = new Instrutor[2]; 
    }

    public static Curso lerDadosCurso() {
        Scanner sc = new Scanner(System.in);
        System.out.println("\n*** NOVO CURSO ***");
        System.out.print("Título: ");
        String tit = sc.nextLine();
        System.out.print("Carga Horária: ");
        int ch = Integer.parseInt(sc.nextLine());
        System.out.print("Valor: ");
        double val = Double.parseDouble(sc.nextLine());
        System.out.print("Categoria: ");
        String cat = sc.nextLine();

        Curso c = new Curso(tit, ch, val, cat);
        System.out.print("Quantos instrutores para este curso (1 ou 2)? ");
        int qtd = Integer.parseInt(sc.nextLine());
        for (int i = 0; i < qtd && i < 2; i++) {
            c.instrutores[i] = Instrutor.lerDadosInstrutor();
        }
        return c;
    }

    public void exibirInfo() {
        System.out.println(this.toString());
    }

    public void exibirInfo(String aviso) {
        System.out.println("[" + aviso + "]");
        this.exibirInfo();
    }

    @Override
    public String toString() {
        String base = "Curso: " + titulo + " | Categoria: " + categoria + " | CH: " + cargaHoraria + "h | R$" + valor;
        for (Instrutor i : instrutores) {
            if (i != null) base += "\n  -> " + i.toString();
        }
        return base;
    }

    public static Curso[] pesquisar(Curso[] cursos, String categoriaBusca) {
        Curso[] resultados = new Curso[cursos.length];
        int cont = 0;
        for (Curso c : cursos) {
            if (c != null && c.categoria.equalsIgnoreCase(categoriaBusca)) {
                resultados[cont++] = c;
            }
        }
        return resultados;
    }
}
