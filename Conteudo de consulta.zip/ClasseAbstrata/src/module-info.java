module ClasseAbstrata {
}