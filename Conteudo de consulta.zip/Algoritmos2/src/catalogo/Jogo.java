package catalogo;

public class Jogo {
	private String nome;
	private int anoLancamento;
	private Double preco;
	private String produtora;
	private String genero;

	public Jogo( String Nome, int dataLancamento, Double Preco, String Produtora, String Genero ){
	this.nome = Nome;
	this.anoLancamento = dataLancamento;
	this.preco = Preco;
	this.produtora = Produtora;
	this.genero = Genero;
	 
}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getAnoLancamento() {
		return anoLancamento;
	}

	public void setAnoLancamento(int anoLancamento) {
		this.anoLancamento = anoLancamento;
	}

	public Double getPreco() {
		return preco;
	}

	public void setPreco(Double preco) {
		this.preco = preco;
	}

	public String getProdutora() {
		return produtora;
	}

	public void setProdutora(String produtora) {
		this.produtora = produtora;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	@Override
	public String toString() {
		return "Jogo [nome=" + nome + ", anoLancamento=" + anoLancamento + ", preco=" + preco + ", produtora="
				+ produtora + ", genero=" + genero + "]";
	}
	
}
