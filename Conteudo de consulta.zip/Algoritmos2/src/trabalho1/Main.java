package trabalho1;
import java.util.Scanner;

public class Main {

	private static Scanner scanner = new Scanner(System.in);
	
	public static Telefone LerTelefone() {
		System.out.print("Insira o seu DDI:");
		String ddi = scanner.nextLine();
		System.out.print("Insira o seu DDD:");
		String ddd = scanner.nextLine();
		System.out.print("Insira seu número telefone:");
		String numero = scanner.nextLine();
		
		
		return new Telefone(ddi,ddd,numero);
	}
	public static Aluno LerAluno() {
		System.out.print("Insira o nome do aluno:");
		String nome = scanner.nextLine();
		System.out.print("Insira o cpf do aluno:");
		String cpf = scanner.nextLine();
		System.out.print("Insira a matricula do aluno:");
		String matricula = scanner.nextLine();
		Telefone telefone = LerTelefone();
		
		
		return new Aluno(nome,cpf,matricula,telefone);
	}
	public static void imprimir(Aluno[] vetAluno) {
		System.out.println("Aqui está os dados dos Alunos:");
		for(Aluno aluno : vetAluno) {
			System.out.println(aluno);
		}
	}
	public static void main(String[] args) {
		final int tamanhoVetor = 3;
		Aluno[] alunos = new Aluno[tamanhoVetor];
		for(int i = 0; i < tamanhoVetor; i++) {
		System.out.println("Cadastro do aluno " + (i + 1) + "   ");
		alunos[i] = LerAluno();
		}
		imprimir(alunos);
		scanner.close();
	}
}
	
	
