package trabalho1;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Professor {
	private String nome;
	private String id;
	private String disciplina;
	private Telefone telefone;

	public static void main (String[] args) {
		LocalDate data = LocalDate.now();
		System.out.println(data);
		
		String dataFormatada = data.format(DateTimeFormatter.ofPattern("dd-MM-yy"));
		System.out.println(dataFormatada);
		
	}
	
	public Professor(String nomeProfessor, String idProfessor, String disProfessor, Telefone telProfessor) {
		nome = nomeProfessor;
		id = idProfessor;
		disciplina = disProfessor;
		telefone = telProfessor;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String Novonome) {
		this.nome = Novonome;
	}

	public String getId() {
		return id;
	}

	public void setId(String Novoid) {
		this.id = Novoid;
	}

	public String getDisciplina() {
		return disciplina;
	}

	public void setDisciplina(String Novadisciplina) {
		this.disciplina = Novadisciplina;
	}

	public Telefone getTelefone() {
		return telefone;
	}

	public void setTelefone(Telefone Novotelefone) {
		this.telefone = Novotelefone;
	}

	@Override
	public String toString() {
		return "Professor [nome=" + nome + ", id=" + id + ", disciplina=" + disciplina + ", telefone=" + telefone + "]";
	}

}
