package trabalho1;

import java.util.Objects;

public class Aluno {

	private String nome;
	private String cpf;
	private String matricula;
	private Telefone telefone;
	
	public Aluno(String nomeAluno, String cpfAluno, String matAluno) {
		this.nome = nomeAluno;
		this.cpf= cpfAluno;
		this.matricula = matAluno;
	}

	public Aluno(String nomeAluno, String cpfAluno, String matAluno, Telefone telAluno) {
		this(nomeAluno, cpfAluno, matAluno);
		this.telefone = telAluno;
	}

	// MÉTODO ORIGINAL
	public void exibirDados() {
		System.out.println(this.toString());
	}

	// MÉTODO SOBRECARREGADO
	public void exibirDados(boolean mostrarApenasNome) {
		if (mostrarApenasNome) {
			System.out.println("Nome do Aluno: " + this.nome);
		} else {
			exibirDados(); // Chama a versão sem parâmetros
		}
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String Novonome) {
		this.nome = Novonome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String Novocpf) {
		this.cpf = Novocpf;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String Novamatricula) {
		this.matricula = Novamatricula;
	}

	public Telefone getTelefone() {
		return telefone;
	}

	public void setTelefone(Telefone Novotelefone) {
		this.telefone = Novotelefone;
	}

	@Override
	public int hashCode() {
		return Objects.hash(cpf, matricula, nome, telefone);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Aluno other = (Aluno) obj;
		return Objects.equals(cpf, other.cpf) && Objects.equals(matricula, other.matricula)
				&& Objects.equals(nome, other.nome) && Objects.equals(telefone, other.telefone);
	}

	@Override
	public String toString() {
		return "Aluno [nome=" + nome + ", cpf=" + cpf + ", matricula=" + matricula + ", telefone=" + telefone + "]";
	}

}
