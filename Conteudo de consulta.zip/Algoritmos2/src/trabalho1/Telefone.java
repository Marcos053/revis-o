package trabalho1;

import java.util.Objects;

public class Telefone {

	private String ddd;
	private String numero;
	private String ddi;
	
	public Telefone(String codigoArea) {
		this.ddd = codigoArea;
		
	}
	
	public Telefone(String codigoArea, String valorNum, String codigoInternacional) {
		this(codigoArea);
		this.numero = valorNum;
		this.ddi = codigoInternacional;

	}

	public String getDdd() {
		return ddd;
	}

	public void setDdd(String Novoddd) {
		this.ddd = Novoddd;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String Novonumero) {
		this.numero = Novonumero;
	}

	public String getDdi() {
		return ddi;
	}

	public void setDdi(String Novoddi) {
		this.ddi = Novoddi;
	}
	@Override
	public int hashCode() {
		return Objects.hash(ddd, ddi, numero);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Telefone other = (Telefone) obj;
		return Objects.equals(ddd, other.ddd) && Objects.equals(ddi, other.ddi) && Objects.equals(numero, other.numero);
	}

	@Override
	public String toString() {
		return "Telefone [ddd=" + ddd + ", numero=" + numero + ", ddi=" + ddi + "]";

	}

}
