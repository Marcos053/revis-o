package trabalho2;

import java.util.Scanner;

public class Corrida {

	private static Scanner scanner = new Scanner(System.in);

	public static Carro carro() {
		System.out.println("---Cadastro do Carro---");
		System.out.println("Qual é o modelo do carro?:");
        String modelo = scanner.nextLine();
		System.out.println("insira a velocidade inicial do carro:");
		Double velocidade = scanner.nextDouble();
		System.out.println("Qual a cilindrada do carro?:");
		Double cilindrada = scanner.nextDouble();
		System.out.println("Qual é o peso do carro em Kg?:");
		Double peso = scanner.nextDouble();

		scanner.nextLine();
		Carro c = new Carro(modelo, velocidade, cilindrada, peso);
		c.acelerar();
		return c;

	}

	public static Moto moto() {
		System.out.println("Qual é o modelo da moto?:");
		String modelo = scanner.nextLine();
		System.out.println("insira a velocidade inicial da moto:");
		Double velocidade = scanner.nextDouble();
		System.out.println("Qual a cilindrada da moto?:");
		Double cilindrada = scanner.nextDouble();
		System.out.println("Qual é o peso da moto em KG?:");
		Double peso = scanner.nextDouble();

		scanner.nextLine();
		Moto m = new Moto(modelo, velocidade, cilindrada, peso);
		m.acelerar();
		return m;

	}

	public static void realizarCorridaCarros(Carro c1, Carro c2, Carro c3, Carro c4) {
		System.out.println("======= Iniciando Corrida! =======");
		for (int segundo = 1; segundo <= 20; segundo++) {
			if (segundo == 6 || segundo == 11 || segundo == 15) {
				c1.Frear();
				c2.Frear();
				c3.Frear();
				c4.Frear();
				System.out.println("Segundo " + segundo + ": Todos os veículos reduziram a velocidade.");
			} else {
				c1.acelerar();
				c2.acelerar();
				c3.acelerar();
				c4.acelerar();
				System.out.printf(" -> %s: %.2f km/h\n", c1.getModelo(), c1.getVelocidade());
				System.out.printf(" -> %s: %.2f km/h\n", c2.getModelo(), c2.getVelocidade());
				System.out.printf(" -> %s: %.2f km/h\n", c3.getModelo(), c3.getVelocidade());
				System.out.printf(" -> %s: %.2f km/h\n", c4.getModelo(), c4.getVelocidade());
			}
		}

		System.out.println("\n======= Resultado final =======");
		System.out.printf("1. %s: %.2f km/h\n", c1.getModelo(), c1.getVelocidade());
		System.out.printf("2. %s: %.2f km/h\n", c2.getModelo(), c2.getVelocidade());
		System.out.printf("3. %s: %.2f km/h\n", c3.getModelo(), c3.getVelocidade());
		System.out.printf("4. %s: %.2f km/h\n", c4.getModelo(), c4.getVelocidade());

		Carro vencedor = c1;

		if (c2.getVelocidade() > vencedor.getVelocidade()) {
			vencedor = c2;
		}
		if (c3.getVelocidade() > vencedor.getVelocidade()) {
			vencedor = c3;
		}
		if (c4.getVelocidade() > vencedor.getVelocidade()) {
			vencedor = c4;
		}

		System.out.println(" O vencendor é: " + vencedor.getModelo() + "!");
	}

	public static void realizarCorridaMotos(Moto m1, Moto m2, Moto m3, Moto m4) {
		System.out.println("======= Iniciando Corrida! =======");
		for (int segundo = 1; segundo <= 20; segundo++) {
			if (segundo == 6 || segundo == 11 || segundo == 15) {
				m1.Frear();
				m2.Frear();
				m3.Frear();
				m4.Frear();
				System.out.println("Segundo " + segundo + ": Todos as Motos reduziram a velocidade.");
			} else {
				m1.acelerar();
				m2.acelerar();
				m3.acelerar();
				m4.acelerar();
				System.out.println("Segundo " + segundo + ": [ACELERAÇÃO]");
				System.out.printf(" -> %s: %.2f km/h\n", m1.getModelo(), m1.getVelocidade());
				System.out.printf(" -> %s: %.2f km/h\n", m2.getModelo(), m2.getVelocidade());
				System.out.printf(" -> %s: %.2f km/h\n", m3.getModelo(), m3.getVelocidade());
				System.out.printf(" -> %s: %.2f km/h\n", m4.getModelo(), m4.getVelocidade());
			}
		}

		System.out.println("\n======= Resultado final =======");
		System.out.printf("1. %s: %.2f km/h\n", m1.getModelo(), m1.getVelocidade());
		System.out.printf("2. %s: %.2f km/h\n", m2.getModelo(), m2.getVelocidade());
		System.out.printf("3. %s: %.2f km/h\n", m3.getModelo(), m3.getVelocidade());
		System.out.printf("4. %s: %.2f km/h\n", m4.getModelo(), m4.getVelocidade());
		Moto vencedor = m1;

		if (m2.getVelocidade() > vencedor.getVelocidade()) {
			vencedor = m2;
		}
		if (m3.getVelocidade() > vencedor.getVelocidade()) {
			vencedor = m3;
		}
		if (m4.getVelocidade() > vencedor.getVelocidade()) {
			vencedor = m4;
		}

		System.out.println(" O vencendor é: " + vencedor.getModelo() + "!");
	}

	public static void main(String[] args) {
		Carro c1 = Corrida.carro();
		Carro c2 = Corrida.carro();
		Carro c3 = Corrida.carro();
		Carro c4 = Corrida.carro();

		Corrida.realizarCorridaCarros(c1, c2, c3, c4);

		Moto m1 = Corrida.moto();
		Moto m2 = Corrida.moto();
		Moto m3 = Corrida.moto();
		Moto m4 = Corrida.moto();

		Corrida.realizarCorridaMotos(m1, m2, m3, m4);

	}

}
