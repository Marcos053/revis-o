package trabalho2;

public class Carro {

	private String modelo;
	private Double velocidade;
	private Double cilindrada;
	private Double peso;

	public Carro(String ModeloCarro, Double VelocidadeKM, Double cilindradaPer, Double pesoKg) {
		this.modelo = ModeloCarro;
		this.velocidade = VelocidadeKM;
		this.cilindrada = cilindradaPer;
		this.peso = pesoKg;
	}

	public void acelerar() {
		this.velocidade += 5.0;
		double ganho = this.velocidade * (0.15 * this.cilindrada);
		this.velocidade += ganho;
		this.velocidade -= (this.peso / 300.0);

		if (this.velocidade < 0)this.velocidade = 0.0;
	}

	public void Frear() {
		velocidade -= velocidade * 0.25;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String NovoModelo) {
		this.modelo = NovoModelo;
	}

	public Double getVelocidade() {
		return velocidade;
	}

	public void setVelocidade(Double NovaVelocidade) {
		this.velocidade = NovaVelocidade;
	}

	public Double getCilindrada() {
		return cilindrada;
	}

	public void setCilindrada(Double NovaCilindrada) {
		this.cilindrada = NovaCilindrada;
	}

	@Override
	public String toString() {
		return "Carro [modelo=" + modelo + ", velocidade=" + velocidade + ", cilindrada=" + cilindrada + "]";
	}

}
