package Trabalho;


import java.util.ArrayList;
import java.util.List;

public class Pessoa implements Impressao {
    private String nome;
    private int idade;
    private Sexo sexo; 
    private List<Telefone> telefones; 

   
    public Pessoa() {
        this.telefones = new ArrayList<>();
    }

   
    public Pessoa(String nome, int idade, Sexo sexo) {
        this.nome = nome;
        this.idade = idade;
        this.sexo = sexo;
        this.telefones = new ArrayList<>();
    }

    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public Sexo getSexo() {
        return sexo;
    }

    public void setSexo(Sexo sexo) {
        this.sexo = sexo;
    }

    public List<Telefone> getTelefones() {
        return telefones;
    }

    public void adicionarTelefone(Telefone telefone) {
        this.telefones.add(telefone);
    }

    
    @Override
    public String toString() {
        return "Nome: " + nome + ", Idade: " + idade + ", Sexo: " + sexo + ", Telefones: " + telefones;
    }

  
    @Override
    public void imprimir() {
        System.out.println("--- Dados da Pessoa ---");
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        System.out.println("Sexo: " + sexo);
        System.out.print("Telefones: ");
        if (telefones.isEmpty()) {
            System.out.println("Nenhum telefone cadastrado.");
        } else {
            System.out.println();
            for (Telefone t : telefones) {
                System.out.print("  - ");
                t.imprimir(); 
            }
        }
    }
}