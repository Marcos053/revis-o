package Trabalho;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Principal {

	private static final Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		List<Pessoa> listaPessoas = new ArrayList<>();

		System.out.println("=== CADASTRO DE 5 PESSOAS ===");
		for (int i = 1; i <= 5; i++) {
			System.out.println("\nCadastro da " + i + "ª pessoa:");
			listaPessoas.add(lerDados());
		}

		System.out.println("\n=================================");
		System.out.println("IMPRESSÃO DA LISTA COMPLETA (Q3)");
		System.out.println("=================================");
		imprimirLista(listaPessoas);

		System.out.println("\n=================================");
		System.out.println("IMPRESSÃO APENAS DO SEXO MASCULINO (Q4)");
		System.out.println("=================================");
		imprimirLista(listaPessoas, Sexo.MASCULINO);

		System.out.println("\n=================================");
		System.out.println("ORDENAÇÕES USANDO CLASSES ANÔNIMAS (Q5)");
		System.out.println("=================================");

		System.out.println("\n--> Ordenado por Nome (Classe Anônima):");
		imprimirListaOrdenadaPorNome(listaPessoas);

		System.out.println("\n--> Ordenado por Idade (Classe Anônima):");
		imprimirListaOrdenadaPorIdade(listaPessoas);

		System.out.println("\n--> Ordenado por Sexo (Classe Anônima):");
		imprimirListaOrdenadaPorSexo(listaPessoas);

		System.out.println("\n=================================");
		System.out.println("ORDENAÇÕES USANDO EXPRESSÕES LAMBDA (Q6)");
		System.out.println("=================================");

		System.out.println("\n--> Ordenado por Nome (Lambda):");
		imprimirListaOrdenadaPorNomeLambda(listaPessoas);

		System.out.println("\n--> Ordenado por Idade (Lambda):");
		imprimirListaOrdenadaPorIdadeLambda(listaPessoas);

		System.out.println("\n--> Ordenado por Sexo (Lambda):");
		imprimirListaOrdenadaPorSexoLambda(listaPessoas);
	}

	public static Pessoa lerDados() {
		System.out.print("Digite o nome: ");
		String nome = scanner.nextLine();

		System.out.print("Digite a idade: ");
		int idade = Integer.parseInt(scanner.nextLine());

		System.out.print("Digite o sexo (M para Masculino / F para Feminino): ");
		String opcaoSexo = scanner.nextLine().trim().toUpperCase();
		Sexo sexo = opcaoSexo.equals("F") ? Sexo.FEMININO : Sexo.MASCULINO;

		Pessoa p = new Pessoa(nome, idade, sexo);

		System.out.print("Deseja cadastrar um telefone para esta pessoa? (S/N): ");
		String opcaoTel = scanner.nextLine().trim().toUpperCase();
		if (opcaoTel.equals("S")) {
			System.out.print("Digite o código de área (DDD): ");
			String ddd = scanner.nextLine();
			System.out.print("Digite o número do telefone: ");
			String numero = scanner.nextLine();
			p.adicionarTelefone(new Telefone(ddd, numero));
		}

		return p;
	}

	public static void imprimirLista(List<Pessoa> lista) {
		for (Pessoa p : lista) {
			p.imprimir();
			System.out.println("---------------------------------");
		}
	}

	public static void imprimirLista(List<Pessoa> lista, Sexo sexo) {
		for (Pessoa p : lista) {
			if (p.getSexo() == sexo) {
				p.imprimir();
				System.out.println("---------------------------------");
			}
		}
	}

	public static void imprimirListaOrdenadaPorNome(List<Pessoa> lista) {

		List<Pessoa> auxiliar = new ArrayList<>(lista);
		auxiliar.sort(new Comparator<Pessoa>() {
			@Override
			public int compare(Pessoa o1, Pessoa o2) {
				return o1.getNome().compareTo(o2.getNome());
			}
		});
		imprimirLista(auxiliar);
	}

	public static void imprimirListaOrdenadaPorIdade(List<Pessoa> lista) {
		List<Pessoa> auxiliar = new ArrayList<>(lista);
		auxiliar.sort(new Comparator<Pessoa>() {
			@Override
			public int compare(Pessoa o1, Pessoa o2) {
				if (o1.getIdade() < o2.getIdade())
					return -1;
				else if (o1.getIdade() == o2.getIdade())
					return 0;
				else
					return 1;
			}
		});
		imprimirLista(auxiliar);
	}

	public static void imprimirListaOrdenadaPorSexo(List<Pessoa> lista) {
		List<Pessoa> auxiliar = new ArrayList<>(lista);
		auxiliar.sort(new Comparator<Pessoa>() {
			@Override
			public int compare(Pessoa o1, Pessoa o2) {
				return o1.getSexo().toString().compareTo(o2.getSexo().toString());
			}
		});
		imprimirLista(auxiliar);
	}

	public static void imprimirListaOrdenadaPorNomeLambda(List<Pessoa> lista) {
		List<Pessoa> auxiliar = new ArrayList<>(lista);

		auxiliar.sort((o1, o2) -> o1.getNome().compareTo(o2.getNome()));
		imprimirLista(auxiliar);
	}

	public static void imprimirListaOrdenadaPorIdadeLambda(List<Pessoa> lista) {
		List<Pessoa> auxiliar = new ArrayList<>(lista);

		auxiliar.sort((o1, o2) -> Integer.compare(o1.getIdade(), o2.getIdade()));
		imprimirLista(auxiliar);
	}

	public static void imprimirListaOrdenadaPorSexoLambda(List<Pessoa> lista) {
		List<Pessoa> auxiliar = new ArrayList<>(lista);
		auxiliar.sort((o1, o2) -> o1.getSexo().compareTo(o2.getSexo()));
		imprimirLista(auxiliar);
	}
}
