package Trabalho;


public interface Impressao {
    void imprimir();
}