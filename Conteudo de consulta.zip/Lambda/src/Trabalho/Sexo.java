package Trabalho;

public enum Sexo {
    MASCULINO,
    FEMININO;
}
