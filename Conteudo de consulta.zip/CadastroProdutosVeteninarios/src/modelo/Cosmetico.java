package modelo;

import java.time.LocalDate;

public class Cosmetico extends Produto {
    private String fragrancia;
    private String volume;

    public Cosmetico(String nome, String marca, double preco, LocalDate validade, String fragrancia, String volume) {
        super(nome, marca, preco, validade);
        this.fragrancia = fragrancia;
        this.volume = volume;
    }

    @Override
    public void imprimir() {
        super.imprimir();
        System.out.println("Fragrância: " + fragrancia + " | Volume: " + volume);
    }
}