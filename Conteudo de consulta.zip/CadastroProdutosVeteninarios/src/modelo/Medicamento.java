package modelo;

import java.time.LocalDate;

public class Medicamento extends Produto {
    private String contraIndicacao;
    private boolean precisaReceita;

    public Medicamento(String nome, String marca, double preco, LocalDate validade, String contraIndicacao, boolean precisaReceita) {
        super(nome, marca, preco, validade);
        this.contraIndicacao = contraIndicacao;
        this.precisaReceita = precisaReceita;
    }

    @Override
    public void imprimir() {
        super.imprimir();
        System.out.println("Contra-indicação: " + contraIndicacao + 
                           " | Precisa de Receita: " + (precisaReceita ? "Sim" : "Não"));
    }
}

