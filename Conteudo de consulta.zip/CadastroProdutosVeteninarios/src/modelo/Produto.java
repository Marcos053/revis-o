package modelo;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public abstract class Produto {
	private String nome;
	private String marca;
	private double preco;
	private LocalDate validade;

	public Produto(String nome, String marca, double preco, LocalDate validade) {
		this.nome = nome;
		this.marca = marca;
		this.preco = preco;
		this.validade = validade;
	}

	public void imprimir() {
		DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		System.out.println("Nome: " + nome + " | Marca: " + marca + " | Preço: R$" + preco + " | Validade: "
				+ validade.format(fmt));
	}

	public void imprimir(String titulo) {
		System.out.println("===== " + titulo + " =====");
		this.imprimir();
	}

	public String getNome() {
		return nome;
	}
}
