package principal;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import modelo.Produto;
import modelo.Medicamento;
import modelo.Cosmetico;

public class Principal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Produto[] estoque = new Produto[10]; 
        int indice = 0;
        int opcao = 0;

        while (opcao != 3) {
            System.out.println("\n--- VET-SHOP ---");
            System.out.println("1) Cadastrar Produto");
            System.out.println("2) Pesquisar por Nome");
            System.out.println("3) Sair");
            System.out.print("Escolha: ");
            opcao = Integer.parseInt(sc.nextLine());

            if (opcao == 1) {
                if (indice < 10) {
                    estoque[indice++] = lerDadosProduto();
                } else {
                    System.out.println("Estoque cheio!");
                }
            } else if (opcao == 2) {
                System.out.print("Nome do produto: ");
                String nomeBusca = sc.nextLine();
                Produto[] encontrados = pesquisar(estoque, nomeBusca);
                
                for (Produto p : encontrados) {
                    if (p != null) p.imprimir("INFO PRODUTO"); // Uso da sobrecarga
                }
            }
        }
        sc.close();
    }

    public static Produto lerDadosProduto() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Tipo (1-Medicamento / 2-Cosmético): ");
        int tipo = Integer.parseInt(sc.nextLine());

        System.out.print("Nome: ");
        String nome = sc.nextLine();
        System.out.print("Marca: ");
        String marca = sc.nextLine();
        System.out.print("Preço: ");
        double preco = Double.parseDouble(sc.nextLine());
        System.out.print("Validade (dd/mm/aaaa): ");
        LocalDate data = LocalDate.parse(sc.nextLine(), DateTimeFormatter.ofPattern("dd/MM/yyyy"));

        if (tipo == 1) {
            System.out.print("Contra-indicação: ");
            String ci = sc.nextLine();
            System.out.print("Precisa receita (true/false): ");
            boolean pr = Boolean.parseBoolean(sc.nextLine());
            return new Medicamento(nome, marca, preco, data, ci, pr);
        } else {
            System.out.print("Fragrância: ");
            String fr = sc.nextLine();
            System.out.print("Volume: ");
            String vol = sc.nextLine();
            return new Cosmetico(nome, marca, preco, data, fr, vol);
        }
    }

    public static Produto[] pesquisar(Produto[] vet, String nome) {
        Produto[] resultados = new Produto[vet.length];
        int j = 0;
        for (Produto p : vet) {
            if (p != null && p.getNome().equalsIgnoreCase(nome)) {
                resultados[j++] = p;
            }
        }
        return resultados;
    }
}