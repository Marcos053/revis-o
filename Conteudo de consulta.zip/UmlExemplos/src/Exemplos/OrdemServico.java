package Exemplos;

public class OrdemServico {
	int numeroOs;
	String DescricaoProblema;
	double ValorTotal;
	String dataEntrada;

}
