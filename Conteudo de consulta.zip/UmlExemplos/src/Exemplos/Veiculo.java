package Exemplos;

public class Veiculo {
    private String placa;
    private String modelo;
    private String marca;
    private int ano;
    private Cliente dono;
    // Cardinalidade * representada por um vetor
    private OrdemServico[] ordens; 


    public Veiculo(String placa, String modelo, String marca, int ano, int limiteOS) {
        this.placa = placa;
        this.modelo = modelo;
        this.marca = marca;
        this.ano = ano;
        // Inicializamos o vetor com um tamanho definido
        this.ordens = new OrdemServico[limiteOS]; 
    }
}
