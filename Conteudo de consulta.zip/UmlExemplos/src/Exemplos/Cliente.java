package Exemplos;

public class Cliente {
    private String nome;
    // Associação com cardinalidade * exige []
    private Veiculo[] veiculos; 

    public Cliente(String nome, int qtdMaxVeiculos) {
        this.nome = nome;
        this.veiculos = new Veiculo[qtdMaxVeiculos];
    }
}