package jogo;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Jogo {
	private String nome;
	private double preco;
	private LocalDate dataLancamento;
	private Genero genero;

	public Jogo(String nome, double preco, LocalDate dataLancamento, Genero genero) {
		this.nome = nome;
		this.preco = preco;
		this.dataLancamento = dataLancamento;
		this.genero = genero;
	}

	public Genero getGenero() {
		return genero;
	}

	@Override
	public String toString() {
		DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		return String.format("Jogo: %-15s | Preço: R$ %6.2f | Lançamento: %s | Gênero: %s", nome, preco,
				dataLancamento.format(fmt), genero);
	}
}