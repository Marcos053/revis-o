package jogo;

import java.time.LocalDate;

public class Principal {
	public static void main(String[] args) {

		Jogo[] catalogo = new Jogo[4];

		catalogo[0] = new Jogo("The Legend of Zelda: Breath of the wild", 249.90, LocalDate.of(2017, 3, 3), Genero.RPG);
		catalogo[1] = new Jogo("Call off Duty Modern warfare", 0.00, LocalDate.of(2022, 10, 28), Genero.FPS);
		catalogo[2] = new Jogo("The Witcher 3", 120.00, LocalDate.of(2015, 5, 19), Genero.RPG);
		catalogo[3] = new Jogo("Resident Evil Requiem", 300.00, LocalDate.of(2026, 2, 27), Genero.TERROR);

		System.out.println("=== LISTAGEM COMPLETA DO CATÁLOGO ===");
		for (Jogo jogo : catalogo) {
			if (jogo != null) {
				System.out.println(jogo);
			}
		}

		realizarBusca(catalogo, Genero.RPG);
	}

	public static void realizarBusca(Jogo[] vetor, Genero filtro) {
		System.out.println("\n=== RESULTADOS DA BUSCA POR GÊNERO: " + filtro + " ===");
		boolean encontrado = false;

		for (Jogo jogo : vetor) {
			if (jogo != null && jogo.getGenero() == filtro) {
				System.out.println(jogo);
				encontrado = true;
			}
		}

		if (!encontrado) {
			System.out.println("Nenhum jogo encontrado para este gênero.");
		}
	}
}
