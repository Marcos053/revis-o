package jogo;

public enum Genero {
	RPG, FPS, AVENTURA, ESTRATEGIA, TERROR;
}
