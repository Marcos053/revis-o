package aplicacao;

public enum DiaSemana {
	
	DOMINGO(1, "Domingo"),
	SEGUNDA(2, "Segunda"),
	TERCA(3, "Terça"),
	QUARTA(4, "Quarta"),
	QUINTA(5, "Quinta"),
	SEXTA(6, "Sexta"),
	SABADO(7, "Sábado"),;

	public final int ID;
	public final  String LABEL;
	
	DiaSemana(int id, String label){
		ID = id;
		LABEL = label;
	}
	
	public static  DiaSemana valueOf(int id) {
		for (DiaSemana  dia : values()) {
			if (id == dia.ID)
				return dia;
			
		}
		return null;
	}
	
	@Override
	public String toString() {
		return ID  + "-" +  LABEL;
	}
	}

