package aplicacao;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		DiaSemana dia = null;

		System.out.println("Selecione o dia da semana:");
		for (DiaSemana d : DiaSemana.values()) {
			System.out.println(d);
		}

		int valor = scan.nextInt();

		dia = DiaSemana.valueOf(valor);

		System.out.println(dia.ID);

	}

}
