package Trabalho4;

public class Computador {
	private String marca;
	private String modelo;
	private int ram;
	private int amazenamento;
	public Computador(String marca, String modelo, int ram, int amazenamento) {
		super();
		this.marca = marca;
		this.modelo = modelo;
		this.ram = ram;
		this.amazenamento = amazenamento;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public int getRam() {
		return ram;
	}
	public void setRam(int ram) {
		this.ram = ram;
	}
	public int getAmazenamento() {
		return amazenamento;
	}
	public void setAmazenamento(int amazenamento) {
		this.amazenamento = amazenamento;
	}
	@Override
	public String toString() {
		return "Computador [marca=" + marca + ", modelo=" + modelo + ", ram=" + ram + ", amazenamento=" + amazenamento
				+ "]";
	}

}
