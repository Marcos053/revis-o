package Trabalho4;

public class SistemaOperacional {
	private String nome;
	private String versao;
	private String arquitetura;
	private String lincencaChave;

	public SistemaOperacional(String nome, String versao, String arquitetura, String lincencaChave) {
		super();
		this.nome = nome;
		this.versao = versao;
		this.arquitetura = arquitetura;
		this.lincencaChave = lincencaChave;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getVersao() {
		return versao;
	}

	public void setVersao(String versao) {
		this.versao = versao;
	}

	public String getArquitetura() {
		return arquitetura;
	}

	public void setArquitetura(String arquitetura) {
		this.arquitetura = arquitetura;
	}

	public String getLincencaChave() {
		return lincencaChave;
	}

	public void setLincencaChave(String lincencaChave) {
		this.lincencaChave = lincencaChave;
	}

	@Override
	public String toString() {
		return "SistemaOperacional [nome=" + nome + ", versao=" + versao + ", arquitetura=" + arquitetura
				+ ", lincencaChave=" + lincencaChave + "]";
	}

}
