package Trabalho4;

public class Carro {
	private String marca;
	private String modelo;
	private Double peso;
	private int ano;
	
	public Carro(String marca, String modelo, Double peso, int ano) {
		super();
		this.marca = marca;
		this.modelo = modelo;
		this.peso = peso;
		this.ano = ano;
	}
	
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public Double getPeso() {
		return peso;
	}
	public void setPeso(Double peso) {
		this.peso = peso;
	}
	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}

	@Override
	public String toString() {
		return "Carro [marca=" + marca + ", modelo=" + modelo + ", peso=" + peso + "]";
	}

}
