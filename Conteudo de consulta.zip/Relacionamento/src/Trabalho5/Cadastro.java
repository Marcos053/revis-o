package Trabalho5;

import java.time.LocalDate;
import java.util.Scanner;

public class Cadastro {
	private static Scanner scanner = new Scanner(System.in);

	public static Funcionario CadastrarFuncionario() {
		System.out.println("Digite o nome do Funcionario:");
		String nome = scanner.nextLine();
		System.out.println("Digite a idade do Funcionario:");
		int idade = scanner.nextInt();
		scanner.nextLine();
		System.out.println("Digite o cpf do Funcionario:");
		String cpf = scanner.nextLine();

		System.out.print("Digite o ano de nascimento: ");
		int ano = scanner.nextInt();
		System.out.print("Digite o mês de nascimento: ");
		int mes = scanner.nextInt();
		System.out.print("Digite o dia de nascimento: ");
		int dia = scanner.nextInt();
		scanner.nextLine();

		LocalDate dataNascimento = LocalDate.of(ano, mes, dia);

		return new Funcionario(nome, idade, cpf, dataNascimento);
	}

	public static void main(String[] args) {
		Funcionario[] Funcionarios = new Funcionario[10];
		int contador = 0;
		int opcao = -1;
		while (opcao != 0) {

			System.out.println("==============MENU==============");
			System.out.println("1- cadastrar:");
			System.out.println("2- listar todos:");
			System.out.println("3- listar por idade");
			System.out.println("Escolha uma das opções:");
			opcao = scanner.nextInt();
			scanner.nextLine();

			switch (opcao) {
			case 1:
				if (contador < 3) {
					Funcionarios[contador] = CadastrarFuncionario();
					contador++;
					System.out.println("Cadastro realizado");
				} else {
					System.out.println("Limite do vetor alcançado");
				}
				break;

			case 2:
				for (int i = 0; i < contador; i++) {
					System.out.println(Funcionarios[i]);
				}
				break;

			case 3:
				System.out.println("Digite a idade para filtrar:");
				int idadeBusca = scanner.nextInt();
				scanner.nextLine();
				System.out.println("Funcionários com " + idadeBusca + " anos:");
				for (int i = 0; i < contador; i++) {
					if (Funcionarios[i].getIdade() == idadeBusca) {
						System.out.println(Funcionarios[i]);
					}
				}
				break;
				
			case 0:
                System.out.println("Encerrando o sistema");
                break;
			}

		}

	}

}
