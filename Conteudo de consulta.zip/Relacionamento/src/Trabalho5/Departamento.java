package Trabalho5;

public class Departamento {
	private String nome;
	private String cnpj;
	private String endereco;
	private String telefone;
	private Funcionario[] funcionarios;

	public Departamento(String nome, String cnpj, String endereco, String telefone, Funcionario[] funcionarios) {
		super();
		this.nome = nome;
		this.cnpj = cnpj;
		this.endereco = endereco;
		this.telefone = telefone;
		this.funcionarios = funcionarios;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public Funcionario[] getFuncionarios() {
		return funcionarios;
	}

	public void setFuncionarios(Funcionario[] funcionarios) {
		this.funcionarios = funcionarios;
	}

	@Override
	public String toString() {
		return "Departamento [nome=" + nome + ", cnpj=" + cnpj + ", endereco=" + endereco + ", telefone=" + telefone
				+ "]";
	}

}
