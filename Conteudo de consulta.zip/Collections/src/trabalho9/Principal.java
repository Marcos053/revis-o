package trabalho9;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Pessoa> listaPessoas = new ArrayList<>();

        System.out.println("--- Cadastro de Pessoas ---");

        
        for (int i = 1; i <= 4; i++) {
            System.out.println("\nDados da " + i + "ª pessoa:");
            
            System.out.print("Nome: ");
            String nome = scanner.nextLine();
            
            System.out.print("CPF: ");
            String cpf = scanner.nextLine();
            
            Sexo sexoEnum = null;
            while (sexoEnum == null) {
                System.out.print("Sexo (M para Masculino, F para Feminino): ");
                String sexoEntrada = scanner.nextLine().trim().toUpperCase();
                
                if (sexoEntrada.equals("M")) {
                    sexoEnum = Sexo.MASCULINO;
                } else if (sexoEntrada.equals("F")) {
                    sexoEnum = Sexo.FEMININO;
                } else {
                    System.out.println("Opção inválida! Digite apenas M ou F.");
                }
            }

            
            listaPessoas.add(new Pessoa(nome, cpf, sexoEnum));
        }

        
        System.out.println("\n--- Lista Original ---");
        imprimirTudo(listaPessoas);

       
        listaPessoas.removeIf(pessoa -> pessoa.getSexo() == Sexo.MASCULINO);
        System.out.println("\n[Sistema]: Pessoas do sexo masculino removidas com sucesso.");

        
        System.out.println("\n--- Lista Após Remoção (Apenas Feminino) ---");
        imprimirTudo(listaPessoas);

        scanner.close();
    }

    
    public static void imprimirTudo(List<Pessoa> lista) {
        if (lista.isEmpty()) {
            System.out.println("A lista está vazia.");
        } else {
            for (Pessoa p : lista) {
                System.out.println(p); 
            }
        }
    }
}
