package trabalho9;

public class Pessoa {
    private String nome;
    private String cpf;
    private Sexo sexo;

    
    public Pessoa(String nome, String cpf, Sexo sexo) {
        this.nome = nome;
        this.cpf = cpf;
        this.sexo = sexo;
    }

   
    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }

    public Sexo getSexo() {
        return sexo;
    }

    
    @Override
    public String toString() {
		return "Nome: " + nome + " | CPF: " + cpf + " | Sexo: " + sexo;
	}
}