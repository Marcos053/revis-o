package trabalho9;

public enum Sexo {
	MASCULINO,
	FEMININO,

}
