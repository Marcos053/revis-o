package app;

import java.util.HashMap;
import java.util.Map;

public class Principal {

	public static void main(String[] args) {
		Map<String, Pessoa> map = new HashMap<String, Pessoa>();
		
		Pessoa janio = new Pessoa("111.111.111-11", "janio@gmail.com" , "Janio");
		Pessoa Leandra = new Pessoa("222.222.222-22", "Leandra@gmail.com" , "Leandra");
		Pessoa Mailson = new Pessoa("333.333.333-33", "Mailson@gmail.com" , "Mailson");
		
		map.put(janio.getEmail(), janio);
		map.put(Leandra.getEmail(), Leandra);
		map.put(Mailson.getEmail(), Mailson );
		
		
		System.out.println(map.get("Leandra@gmail.com"));
		
	
		

	}

}
