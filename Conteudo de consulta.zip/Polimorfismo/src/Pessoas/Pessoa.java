package Pessoas;

import java.util.Objects;

public class Pessoa {
	private Integer id;
	private String nome;
	private String email;

	public Pessoa() {
	}

	public Pessoa(Integer id, String nome, String email) {
		this.id = id;
		this.nome = nome;
		this.email = email;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void imprimir() {
		System.out.println("id: " + id);
		System.out.println("nome: " + nome);
		System.out.println("email: " + email);
	}

	@Override
	public String toString() {

		return "Pessoa [id=" + id + ", nome=" + nome + ", email=" + email + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;

		if (!(obj instanceof Pessoa))
			return false;

		Pessoa p = (Pessoa) obj;

		return Objects.equals(this.id, p.id) && Objects.equals(this.nome, p.nome)
				&& Objects.equals(this.email, p.email);
	}
}
