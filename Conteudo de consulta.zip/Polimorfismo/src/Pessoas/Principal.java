package Pessoas;

public class Principal {
	public static void main(String[] args) {
		Pessoa p = new Pessoa(1, "Marcos Antônio", "MarcosA@exemplo.com");

		PessoaFisica pf = new PessoaFisica(2, "Maria Gabriela", "MariaG@exemplo.com", "397.356.889-00",
				"(63) 99744-0188");

		PessoaJuridica pj = new PessoaJuridica(3, "Empresa qualquer", "contato@empresaQ.com", "92.345.618/0001-89",
				"09876543", "(63) 99127-8988");

		System.out.println("== chamadas imprimir() específicas ==");

		p.imprimir();
		System.out.println("");

		pf.imprimir();
		System.out.println("");

		pj.imprimir();

		System.out.println("\n== usando Impressora.imprimir(Pessoa) ==");

		Impressora.imprimir(p);
		System.out.println("");

		Impressora.imprimir(pf);
		System.out.println("");

		Impressora.imprimir(pj);

	}
}
