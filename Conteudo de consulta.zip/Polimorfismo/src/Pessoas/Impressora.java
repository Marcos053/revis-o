package Pessoas;

public class Impressora {
	public static void imprimir(Pessoa pessoa) {

		if (pessoa instanceof PessoaFisica) {

			PessoaFisica pf = (PessoaFisica) pessoa;

			System.out.println("--- PessoaFisica ---");

			System.out.println("id: " + pf.getId());
			System.out.println("nome: " + pf.getNome());
			System.out.println("email: " + pf.getEmail());

			System.out.println("cpf: " + pf.getCpf());
			System.out.println("celular: " + pf.getCelular());

		} else if (pessoa instanceof PessoaJuridica) {

			PessoaJuridica pj = (PessoaJuridica) pessoa;

			System.out.println("--- PessoaJuridica ---");

			System.out.println("id: " + pj.getId());
			System.out.println("nome: " + pj.getNome());
			System.out.println("email: " + pj.getEmail());

			System.out.println("cnpj: " + pj.getCnpj());
			System.out.println("inscricaoEstadual: " + pj.getInscricaoEstadual());
			System.out.println("telefoneFixo: " + pj.getTelefoneFixo());

		} else {
			System.out.println("--- Pessoa ---");

			pessoa.imprimir();
		}
	}
}
