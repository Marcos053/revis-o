package Pessoas;

import java.util.Objects;

public class PessoaFisica extends Pessoa {
	private String cpf;
	private String celular;

	public PessoaFisica() {
	}

	public PessoaFisica(Integer id, String nome, String email, String cpf, String celular) {
		super(id, nome, email);
		this.cpf = cpf;
		this.celular = celular;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getCelular() {
		return celular;
	}

	public void setCelular(String celular) {
		this.celular = celular;
	}

	@Override
	public void imprimir() {
		super.imprimir();
		System.out.println("cpf: " + cpf);
		System.out.println("celular: " + celular);
	}

	@Override
	public String toString() {
		return super.toString() + " PessoaFisica [cpf=" + cpf + ", celular=" + celular + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;

		if (!(obj instanceof PessoaFisica))
			return false;

		if (!super.equals(obj))
			return false;

		PessoaFisica pf = (PessoaFisica) obj;
		return Objects.equals(this.cpf, pf.cpf) && Objects.equals(this.celular, pf.celular);
	}
}
