package Pessoas;

import java.util.Objects;

public class PessoaJuridica extends Pessoa {

	private String cnpj;
	private String inscricaoEstadual;
	private String telefoneFixo;

	public PessoaJuridica() {
	}

	public PessoaJuridica(Integer id, String nome, String email, String cnpj, String inscricaoEstadual,
			String telefoneFixo) {

		super(id, nome, email);

		this.cnpj = cnpj;
		this.inscricaoEstadual = inscricaoEstadual;
		this.telefoneFixo = telefoneFixo;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getInscricaoEstadual() {
		return inscricaoEstadual;
	}

	public void setInscricaoEstadual(String inscricaoEstadual) {
		this.inscricaoEstadual = inscricaoEstadual;
	}

	public String getTelefoneFixo() {
		return telefoneFixo;
	}

	public void setTelefoneFixo(String telefoneFixo) {
		this.telefoneFixo = telefoneFixo;
	}

	@Override
	public void imprimir() {

		super.imprimir();
		System.out.println("cnpj: " + cnpj);
		System.out.println("inscricaoEstadual: " + inscricaoEstadual);
		System.out.println("telefoneFixo: " + telefoneFixo);
	}

	@Override
	public String toString() {
		return super.toString() + " PessoaJuridica [cnpj=" + cnpj + ", inscricaoEstadual=" + inscricaoEstadual
				+ ", telefoneFixo=" + telefoneFixo + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;

		if (!(obj instanceof PessoaJuridica))
			return false;

		if (!super.equals(obj))
			return false;

		PessoaJuridica pj = (PessoaJuridica) obj;

		return Objects.equals(this.cnpj, pj.cnpj) && Objects.equals(this.inscricaoEstadual, pj.inscricaoEstadual)
				&& Objects.equals(this.telefoneFixo, pj.telefoneFixo);
	}
}
