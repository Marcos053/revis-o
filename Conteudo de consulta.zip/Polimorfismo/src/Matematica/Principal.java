package Matematica;

public class Principal {
	public static void main(String[] args) {

		Cast op = new Cast();

		System.out.println(op.multiplicar(10, 7.1f));
		System.out.println(op.multiplicar(6.8f, 1.4));
		System.out.println(op.multiplicar(9, Double.valueOf(2.3)));
		System.out.println(op.multiplicar(20L, Float.valueOf(7.5f)));
		System.out.println(op.multiplicar(8.8, 5L));
	}
}
