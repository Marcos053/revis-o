package Matematica;

public class Cast {
	
	public int multiplicar(int a, float b) {
		return a * (int) b;

	}

	public int multiplicar(float a, double b) {
		return (int) a * (int) b;

	}

	public int multiplicar(int a, Double b) {
		return a * b.intValue();
	}

	public int multiplicar(long a, Float b) {
		return (int) a * b.intValue();
	}

	public int multiplicar(double a, long b) {
		return (int) a * (int) b;

	}
}
