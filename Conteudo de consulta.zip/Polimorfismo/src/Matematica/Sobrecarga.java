package Matematica;

public class Sobrecarga {
	public int somar(int a, int b) {
		return a + b;
	}

	public double somar(double a, double b) {
		return a + b;
	}

	public float somar(float a, float b) {
		return a + b;
	}

	public int subtrair(int a, int b) {
		return a - b;
	}

	public double multiplicar(double a, double b) {
		return a * b;
	}

	public float dividir(float a, float b) {

		if (b == 0) {
			System.out.println("Erro: Divisão por zero!");
			return 0.0f;
		}
		return a / b;
	}

}
