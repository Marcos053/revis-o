package teste.provas.prova_chat_5.models;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import teste.provas.prova_chat_5.Loja;

public class Desktop extends Computador {
    private Integer potenciaFonteWatts;
    private List<PenteMemoria> memorias;

    public Desktop(Integer id, Double preco, SistemaOperacional sistemaOperacional, Fabricante fabricante,
            Integer potenciaFonteWatts, List<PenteMemoria> memorias) {
        super(id, preco, sistemaOperacional, fabricante);
        this.potenciaFonteWatts = potenciaFonteWatts;
        this.memorias = memorias;
    }

    public static Desktop lerDados(){
        Scanner sc = new Scanner(System.in);

        System.out.print("ID: ");
        Integer id = sc.nextInt();
        sc.nextLine(); // Limpar o buffer

        System.out.print("Preço: ");
        Double preco = sc.nextDouble();
        sc.nextLine(); // Limpar o buffer

        SistemaOperacional.imprimirTodos();
        System.out.print("Opção: ");
        Integer idSistema = sc.nextInt();
        sc.nextLine(); // Limpar o buffer
        SistemaOperacional sistemaOperacional = SistemaOperacional.valueOf(idSistema);

        System.out.println("*** Fabricantes ***");
        Loja.fabricantes.forEach(System.out::println);
        System.out.println("Digite o ID do fabricante: ");
        Integer idFabricante = sc.nextInt();

        Fabricante fabricante = Loja.fabricantes
            .stream()
            .filter(f -> f.getId().equals(idFabricante))
            .findFirst()
            .get();

        System.out.print("Potência da Fonte (Watts): ");
        Integer potenciaFonteWatts = sc.nextInt();
        sc.nextLine(); // Limpar o buffer

        System.out.println("*** Memórias ***");
        List<PenteMemoria> memorias = new ArrayList<>();
        
        while(true){
            System.out.println("Deseja adicionar um pente de memória? (S/N)");
            String opcao = sc.nextLine();
            
            if(opcao.equalsIgnoreCase("N"))
                break;

            else if(opcao.equalsIgnoreCase("S"))
                memorias.add(PenteMemoria.lerDados());
        }

        Desktop c = new Desktop(id, preco, sistemaOperacional, fabricante, potenciaFonteWatts, memorias);

        return c;
    }

    public Integer getPotenciaFonteWatts() {
        return potenciaFonteWatts;
    }

    public void setPotenciaFonteWatts(Integer potenciaFonteWatts) {
        this.potenciaFonteWatts = potenciaFonteWatts;
    }

    public List<PenteMemoria> getMemorias() {
        return memorias;
    }

    public void setMemorias(List<PenteMemoria> memorias) {
        this.memorias = memorias;
    }

    public Integer getCapacidadeTotalMemoria(){
        Integer totalCapacidadeMemoria = 0;
        for (PenteMemoria pente : this.memorias) 
            totalCapacidadeMemoria += pente.getCapacidadeGb();
        
        return totalCapacidadeMemoria;
    }

    public Boolean temAlgumaMemoriaComFreqMin(Integer frequencia){
        Boolean achouMemoriaFreqMin = false;

        for(PenteMemoria pente : this.memorias){
            if(pente.getFrequenciaMhz() >= frequencia)
                achouMemoriaFreqMin = true;
        }

        return achouMemoriaFreqMin;
    }

    @Override
    public String toString(){
        String stringMemorias = "";
        if(this.memorias == null){
            stringMemorias = null;
        }

        else {
            for (PenteMemoria penteMemoria : this.memorias) {
                stringMemorias.concat(penteMemoria.toString());
            }
        }
        
        return "\nTipo: Desktop" +
                super.toString() +
                "\nPotência da Fonte (Watts): " + this.potenciaFonteWatts +
                "\nMemórias: " + stringMemorias == null ? "Sem memórias" : stringMemorias;
    }
}

