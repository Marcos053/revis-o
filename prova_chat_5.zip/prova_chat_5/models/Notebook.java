package teste.provas.prova_chat_5.models;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import teste.provas.prova_chat_5.Loja;

public class Notebook extends Computador {
    private Double polegadasTela;

    public Notebook(Integer id, Double preco, SistemaOperacional sistemaOperacional, Fabricante fabricante,
            Double polegadasTela) {
        super(id, preco, sistemaOperacional, fabricante);
        this.polegadasTela = polegadasTela;
    }

    public static Notebook lerDados(){
        Scanner sc = new Scanner(System.in);

        System.out.print("ID: ");
        Integer id = sc.nextInt();
        sc.nextLine(); // Limpar o buffer

        System.out.print("Preço: ");
        Double preco = sc.nextDouble();
        sc.nextLine(); // Limpar o buffer

        SistemaOperacional.imprimirTodos();
        System.out.print("Opção: ");
        Integer idSistema = sc.nextInt();
        sc.nextLine(); // Limpar o buffer
        SistemaOperacional sistemaOperacional = SistemaOperacional.valueOf(idSistema);

        System.out.println("*** Fabricantes ***");
        Loja.fabricantes.forEach(System.out::println);
        System.out.println("Digite o ID do fabricante: ");
        Integer idFabricante = sc.nextInt();

        Fabricante fabricante = Loja.fabricantes
            .stream()
            .filter(f -> f.getId().equals(idFabricante))
            .findFirst()
            .get();

        System.out.print("Polegadas da Tela: ");
        Double polegadasTela = sc.nextDouble();
        sc.nextLine(); // Limpar o buffer

        Notebook n = new Notebook(id, preco, sistemaOperacional, fabricante, polegadasTela);

        return n;
    }

    public Double getPolegadasTela() {
        return polegadasTela;
    }

    public void setPolegadasTela(Double polegadasTela) {
        this.polegadasTela = polegadasTela;
    }

    @Override
    public String toString(){
        return "\nTipo: Desktop" +
                super.toString() +
                "\nPolegadas da Tela" + this.polegadasTela;
    }
}
