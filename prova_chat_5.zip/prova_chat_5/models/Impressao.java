package teste.provas.prova_chat_5.models;

public interface Impressao {
    void imprimir();
}
