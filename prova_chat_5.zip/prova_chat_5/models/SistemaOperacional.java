package teste.provas.prova_chat_5.models;

public enum SistemaOperacional {
    WINDOWS (1, "Windows"), 
	MAC_OS (2, "Mac Os"), 
	LINUX (3, "Linux");

	private final int ID;
	private final String LABEL;

	SistemaOperacional(int id, String label) {
		this.ID = id;
		this.LABEL = label;
	}

	public static SistemaOperacional valueOf(int id) {
		for (SistemaOperacional s : SistemaOperacional.values()) 
			if (s.getID() == id) 
				return s;

		return null;
	}

	public static void imprimirTodos() {
		System.out.println("*** Sistemas Operacionais ***");
		for (SistemaOperacional g : values()) 
			System.out.println(g.getID() + " - " + g.getLABEL());
	}

	public int getID() {
		return this.ID;
	}

	public String getLABEL() {
		return this.LABEL;
	}
}