package teste.provas.prova_chat_5.models;

import java.util.Scanner;

public class Fabricante {
    private Integer id;
    private String nome;
    private String pais;

    public Fabricante(Integer id, String nome, String pais) {
        this.id = id;
        this.nome = nome;
        this.pais = pais;
    }

    public static Fabricante lerDados(){
        Scanner sc = new Scanner(System.in);

        System.out.print("ID: ");
        Integer id = sc.nextInt();
        sc.nextLine(); // Limpar o buffer

        System.out.print("Nome: ");
        String nome = sc.nextLine();

        System.out.print("País: ");
        String pais = sc.nextLine();

        Fabricante f = new Fabricante(id, nome, pais);

        return f;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    @Override
    public String toString(){
        return "\nFabricante" +
                "\nID: " + this.id +
                "\nNome: " + this.nome +
                "\nPaís: " + this.pais;
    }
}