package teste.provas.prova_chat_5.models;

public abstract class Computador implements Impressao {
    private Integer id;
    private Double preco;
    private SistemaOperacional sistemaOperacional;
    private Fabricante fabricante;

    public Computador(Integer id, Double preco, SistemaOperacional sistemaOperacional, Fabricante fabricante) {
        this.id = id;
        this.preco = preco;
        this.sistemaOperacional = sistemaOperacional;
        this.fabricante = fabricante;
    }

    @Override
    public void imprimir() {
        System.out.println(this);
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }

    public SistemaOperacional getSistemaOperacional() {
        return sistemaOperacional;
    }

    public void setSistemaOperacional(SistemaOperacional sistemaOperacional) {
        this.sistemaOperacional = sistemaOperacional;
    }

    public Fabricante getFabricante() {
        return fabricante;
    }

    public void setFabricante(Fabricante fabricante) {
        this.fabricante = fabricante;
    }
 
    @Override
    public String toString(){
        return "\nID: " + this.id +
                "\nPreço: " + this.preco +
                "\nSistema Operacional: " + this.sistemaOperacional.getLABEL() +
                this.fabricante;
    }
}