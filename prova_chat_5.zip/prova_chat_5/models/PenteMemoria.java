package teste.provas.prova_chat_5.models;

import java.util.Scanner;

public class PenteMemoria {
    private Integer capacidadeGb;
    private Integer frequenciaMhz;

    public PenteMemoria(Integer capacidadeGb, Integer frequenciaMhz) {
        this.capacidadeGb = capacidadeGb;
        this.frequenciaMhz = frequenciaMhz;
    }

    public static PenteMemoria lerDados(){
        Scanner sc = new Scanner(System.in);

        System.out.print("Capacidade (GB): ");
        Integer capacidadeGb = sc.nextInt();
        sc.nextLine(); // Limpar o buffer

        System.out.print("Frequência (Mhz): ");
        Integer frequenciaMhz = sc.nextInt();
        sc.nextLine(); // Limpar o buffer

        PenteMemoria p = new PenteMemoria(capacidadeGb, frequenciaMhz);

        return p;
    }

    public Integer getCapacidadeGb() {
        return capacidadeGb;
    }

    public void setCapacidadeGb(Integer capacidadeGb) {
        this.capacidadeGb = capacidadeGb;
    }

    public Integer getFrequenciaMhz() {
        return frequenciaMhz;
    }

    public void setFrequenciaMhz(Integer frequenciaMhz) {
        this.frequenciaMhz = frequenciaMhz;
    }

    @Override
    public String toString(){
        return "\nPente Memória" + 
                "\nCapacidade: " + this.capacidadeGb + " Gbs" +
                "\nFrequência: " + this.frequenciaMhz + " Mhz";
    }
}
