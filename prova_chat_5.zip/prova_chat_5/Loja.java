package teste.provas.prova_chat_5;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import teste.provas.prova_chat_5.models.Computador;
import teste.provas.prova_chat_5.models.Desktop;
import teste.provas.prova_chat_5.models.Fabricante;
import teste.provas.prova_chat_5.models.Notebook;
import teste.provas.prova_chat_5.models.PenteMemoria;

public class Loja implements CRUD {
    public static List<Computador> listaComputador = new LinkedList<>();
    public static List<Fabricante> fabricantes = new ArrayList<>();
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Loja loja = new Loja();
        int opcaoMenu = 0;

        while(opcaoMenu != 9){
            opcaoMenu = Loja.lerMenu(sc);

            if(opcaoMenu == 1)
                loja.inserirFabricante();

            else if(opcaoMenu == 2){
                System.out.println(
                    "1 - Cadastrar Notebook" +
                    "\n2 - Cdastrar Desktop"
                );
                Integer opcaoCadastro = sc.nextInt();

                if(opcaoCadastro == 1)
                    loja.inserir(Notebook.lerDados());
                else if(opcaoCadastro == 2)
                    loja.inserir(Desktop.lerDados());
            }

            else if(opcaoMenu == 3){
                System.out.print("ID para excluir: ");
                loja.excluir(sc.nextInt());
            }
            else if(opcaoMenu == 4)
                loja.listarTodos();
            else if (opcaoMenu == 5){
                System.out.print("Polegadas Mínimas: ");
                Double polMin = sc.nextDouble();

                System.out.print("Polegadas Máximas: ");
                Double polMax = sc.nextDouble();

                loja.filtrarNotebooksPorPolegadas(polMin, polMax);
            }
            else if(opcaoMenu == 6){
                System.out.print("ID do fabricante: ");
                loja.filtrarPorFabricante(sc.nextInt());
            }
                
        
        }
    }

    private static int lerMenu(Scanner sc){
        System.out.println("*** MENU ***");
        System.out.println(
            "1) Inserir um Fabricante\n" +
            "2) Inserir um Computador\n" +
            "3) Excluir um Computador\n" +
            "4) Listar Todos os Computadores\n" +
            "5) Filtrar Notebooks por faixa de polegadas\n" +
            "6) Filtrar Computadores por Fabricante\n" +
            "7) Filtrar Desktops por memória RAM total\n" +
            "8) Filtrar Desktops com pente acima de uma frequência\n" +
            "9) Sair"
        );
        System.out.print("Opção: ");
        Integer opcao = sc.nextInt();
        sc.nextLine();

        return opcao;
    }

    public void inserirFabricante() {
        Fabricante f = Fabricante.lerDados();
        Loja.fabricantes.add(f);
    }

    @Override
    public void inserir(Computador c) {
        Loja.listaComputador.add(c);
    }

    @Override
    public void excluir(Integer id) {
        Loja.listaComputador
            .removeIf(c -> c.getId().equals(id));
    }

    @Override
    public void listarTodos() {
        Loja.listaComputador
            .stream()
            .sorted((c1, c2) -> c1.getId().compareTo(c2.getId()))
            .forEach(c -> System.out.println(c));
    }

    @Override
    public void filtrarNotebooksPorPolegadas(Double min, Double max) {
        Loja.listaComputador
            .stream()
            .filter(new Predicate<Computador>() {

                @Override
                public boolean test(Computador c) {
                    if(c instanceof Notebook){
                        Notebook n = (Notebook) c;
                        if(n.getPolegadasTela() >= min && n.getPolegadasTela() <= max)
                            return true;
                    }

                    return false;
                }
                
            })
            .forEach(c -> System.out.println(c));
        
        Set<Computador> setComputador = new HashSet<>(Loja.listaComputador);
        Loja.listaComputador = new ArrayList<>(setComputador);
    }

    @Override
    public void filtrarPorFabricante(Integer idFabricante) {
        Loja.listaComputador
            .stream()
            .filter(c -> c.getFabricante().getId().equals(idFabricante))
            .forEach(c -> System.out.println(c));
    }

    @Override
    public void filtrarDesktopsPorRamTotal(Integer ramTotalMinima) {
        Loja.listaComputador
            .stream()
            .filter(c -> c instanceof Desktop)
            .map(c -> (Desktop) c)
            .filter(d -> d.getCapacidadeTotalMemoria() >= ramTotalMinima)
            .sorted((d1, d2) -> d2.getCapacidadeTotalMemoria().compareTo(d1.getCapacidadeTotalMemoria()))
            .forEach(d -> d.imprimir());
    }

    @Override
    public void filtrarDesktopsPorFrequencia(Integer frequenciaMin) {
        Loja.listaComputador
            .stream()
            .filter(c -> c instanceof Desktop)
            .map(c -> (Desktop) c)
            .filter(d -> d.temAlgumaMemoriaComFreqMin(frequenciaMin))
            .forEach(d -> System.out.println("Índice: " + Loja.listaComputador.indexOf(d) + d));
    }
}
