package teste.provas.prova_chat_5;

import teste.provas.prova_chat_5.models.Computador;

public interface CRUD {
    void inserir(Computador c);
    void excluir(Integer id);
    void listarTodos();
    void filtrarNotebooksPorPolegadas(Double min, Double max);
    void filtrarPorFabricante(Integer id);
    void filtrarDesktopsPorRamTotal(Integer ramTotal);
    void filtrarDesktopsPorFrequencia(Integer frequencia);
}
