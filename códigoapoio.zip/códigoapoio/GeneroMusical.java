
public enum GeneroMusical {

    ROCK(1, "Rock"),
    POP(2, "Pop"),
    RAP(3, "Rap"),
    MPB(4, "MPB"),
    SERTANEJO(5, "Sertanejo"),
    PAGODE(6, "Pagode"),
    JAZZ(7, "Jazz"),
    BLUES(8, "Blues"),
    REGGAE(9, "Reggae"),
    FUNK(10, "Funk");

    private Integer id;
    private String label;

    private GeneroMusical(Integer id, String label) {
        this.id = id;
        this.label = label;
    }

    public Integer getId() {
        return id;
    }

    public String getLabel() {
        return label;
    }

}
```
