
public enum FuncaoIntegrante {

    VOCALISTA(1, "Vocalista"),
    GUITARRISTA(2, "Guitarrista"),
    BAIXISTA(3, "Baixista"),
    BATERISTA(4, "Baterista"),
    TECLADISTA(5, "Tecladista");

    private Integer id;
    private String label;

    private FuncaoIntegrante(Integer id, String label) {
        this.id = id;
        this.label = label;
    }

    public Integer getId() {
        return id;
    }

    public String getLabel() {
        return label;
    }

}
```

