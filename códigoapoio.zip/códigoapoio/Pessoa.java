```java
import java.time.LocalDate;
import java.util.Scanner;

public class Pessoa extends Artista {

    private LocalDate dataNascimento;

    public Pessoa(Integer id, String nome, String pais, LocalDate dataNascimento) {
        super(id, nome, pais);
        this.dataNascimento = dataNascimento;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public static Pessoa lerDados(Scanner sc) {

        System.out.print("ID: ");
        Integer id = Integer.parseInt(sc.nextLine());

        System.out.print("Nome: ");
        String nome = sc.nextLine();

        System.out.print("País: ");
        String pais = sc.nextLine();

        System.out.print("Ano de nascimento: ");
        int ano = Integer.parseInt(sc.nextLine());

        System.out.print("Mês: ");
        int mes = Integer.parseInt(sc.nextLine());

        System.out.print("Dia: ");
        int dia = Integer.parseInt(sc.nextLine());

        LocalDate dataNascimento = LocalDate.of(ano, mes, dia);

        return new Pessoa(id, nome, pais, dataNascimento);
    }

    @Override
    public String toString() {

        return super.toString() +
                "\nData de Nascimento: " + dataNascimento;

    }

}
```
