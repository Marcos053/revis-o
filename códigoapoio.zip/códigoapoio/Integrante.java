```java
import java.util.List;
import java.util.Scanner;

public class Integrante {

    private Pessoa pessoa;
    private FuncaoIntegrante funcao;

    public Integrante(Pessoa pessoa, FuncaoIntegrante funcao) {
        this.pessoa = pessoa;
        this.funcao = funcao;
    }

    // Getters e Setters

    public Pessoa getPessoa() {
        return pessoa;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }

    public FuncaoIntegrante getFuncao() {
        return funcao;
    }

    public void setFuncao(FuncaoIntegrante funcao) {
        this.funcao = funcao;
    }

    public static Integrante lerDados(Scanner sc, List<Pessoa> pessoas) {

        System.out.println("\n===== ESCOLHA UMA PESSOA =====");

        for (int i = 0; i < pessoas.size(); i++) {
            System.out.println(i + " - " + pessoas.get(i).getNome());
        }

        int opcao = Integer.parseInt(sc.nextLine());

        Pessoa pessoaSelecionada = pessoas.get(opcao);

        System.out.println("\n===== FUNÇÕES =====");

        FuncaoIntegrante[] funcoes = FuncaoIntegrante.values();

        for (int i = 0; i < funcoes.length; i++) {
            System.out.println(i + " - " + funcoes[i]);
        }

        int opcaoFuncao = Integer.parseInt(sc.nextLine());

        FuncaoIntegrante funcao = funcoes[opcaoFuncao];

        return new Integrante(pessoaSelecionada, funcao);

    }

    @Override
    public String toString() {

        return "Pessoa: " + pessoa.getNome() +
               "\nFunção: " + funcao;

    }

    @Override
    public boolean equals(Object obj) {

        if (this == obj)
            return true;

        if (obj == null)
            return false;

        if (getClass() != obj.getClass())
            return false;

        Integrante other = (Integrante) obj;

        return pessoa.equals(other.pessoa);

    }

    @Override
    public int hashCode() {
        return pessoa.hashCode();
    }

}
```
