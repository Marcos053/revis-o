```java
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Principal {

    private static Scanner sc = new Scanner(System.in);

    private static List<Artista> artistas = new ArrayList<>();
    private static List<Album> albuns = new ArrayList<>();

    public static void main(String[] args) {

        menu();

    }

    public static void menu() {

        int op;

        do {

            System.out.println("\n========== MENU ==========");
            System.out.println("1 - Inserir Artista");
            System.out.println("2 - Inserir Álbum");
            System.out.println("3 - Listar Todos os Artistas");
            System.out.println("4 - Listar Álbuns");
            System.out.println("5 - Listar Artistas de um Álbum");
            System.out.println("6 - Sair");

            System.out.print("Opção: ");

            op = Integer.parseInt(sc.nextLine());

            switch (op) {

                case 1:

                    inserirArtista();
                    break;

                case 2:

                    inserirAlbum();
                    break;

                case 3:

                    buscarArtistas(0);
                    break;

                case 4:

                    imprimirAlbuns();
                    break;

                case 5:

                    listarArtistasAlbum();
                    break;

                case 6:

                    System.out.println("Programa encerrado.");
                    break;

                default:

                    System.out.println("Opção inválida.");

            }

        } while (op != 6);

    }

    public static void inserirArtista() {

        System.out.println("\n1 - Pessoa");
        System.out.println("2 - Banda");

        int op = Integer.parseInt(sc.nextLine());

        switch (op) {

            case 1:

                artistas.add(
                        Pessoa.lerDados(sc)
                );

                break;

            case 2:

                artistas.add(
                        Banda.lerDados(sc)
                );

                break;

            default:

                System.out.println("Tipo inválido.");

        }

    }

    public static void inserirAlbum() {

        if (artistas.isEmpty()) {

            System.out.println("Cadastre artistas primeiro.");

            return;

        }

        albuns.add(

                Album.lerDados(
                        sc,
                        artistas
                )

        );

        System.out.println("Álbum cadastrado com sucesso!");

    }

    ```java
    public static void buscarArtistas(int tipo) {

        artistas.sort(
                (a1, a2) ->
                        a1.getNome().compareToIgnoreCase(a2.getNome())
        );

        System.out.println("\n===== PESSOAS =====");

        for (Artista a : artistas) {

            if (a instanceof Pessoa) {

                System.out.println(a);

                System.out.println("--------------------");

            }

        }

        System.out.println("\n===== BANDAS =====");

        for (Artista a : artistas) {

            if (a instanceof Banda) {

                System.out.println(a);

                System.out.println("--------------------");

            }

        }

    }

    public static void imprimirAlbuns() {

        if (albuns.isEmpty()) {

            System.out.println("Nenhum álbum cadastrado.");

            return;

        }

        albuns.sort(

                (a1, a2) ->

                        a1.getTitulo()
                                .compareToIgnoreCase(
                                        a2.getTitulo()
                                )

        );

        for (Album album : albuns) {

            System.out.println(album);

            System.out.println("-------------------------");

        }

    }

    public static void listarArtistasAlbum() {

        if (albuns.isEmpty()) {

            System.out.println("Nenhum álbum cadastrado.");

            return;

        }

        System.out.print("Digite o título do álbum: ");

        String titulo = sc.nextLine();

        Album encontrado = null;

        for (Album a : albuns) {

            if (a.getTitulo().equalsIgnoreCase(titulo)) {

                encontrado = a;

                break;

            }

        }

        if (encontrado == null) {

            System.out.println("Álbum não encontrado.");

            return;

        }

        List<Integrante> integrantes =
                encontrado.getIntegrantes();

        integrantes.sort(

                (i1, i2) ->

                        i1.getPessoa()
                                .getNome()

                                .compareToIgnoreCase(

                                        i2.getPessoa()
                                                .getNome()

                                )

        );

        System.out.println("\nArtista Principal:");

        System.out.println(
                encontrado.getArtista().getNome()
        );

        System.out.println("\nIntegrantes:");

        for (Integrante i : integrantes) {

            System.out.println(

                    i.getPessoa().getNome()

                            + " - "

                            + i.getFuncao().getLabel()

            );

        }

    }

}
```

```


