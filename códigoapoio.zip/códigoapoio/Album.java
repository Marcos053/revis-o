```java
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class Album {

    private Integer id;
    private String titulo;
    private LocalDate dataLancamento;
    private Artista artista;
    private GeneroMusical genero;
    private List<Integrante> integrantes;

    public Album(Integer id,
                 String titulo,
                 LocalDate dataLancamento,
                 Artista artista,
                 GeneroMusical genero,
                 List<Integrante> integrantes) {

        this.id = id;
        this.titulo = titulo;
        this.dataLancamento = dataLancamento;
        this.artista = artista;
        this.genero = genero;
        this.integrantes = integrantes;
    }

    // ==========================
    // GETTERS E SETTERS
    // ==========================

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public LocalDate getDataLancamento() {
        return dataLancamento;
    }

    public void setDataLancamento(LocalDate dataLancamento) {
        this.dataLancamento = dataLancamento;
    }

    public Artista getArtista() {
        return artista;
    }

    public void setArtista(Artista artista) {
        this.artista = artista;
    }

    public GeneroMusical getGenero() {
        return genero;
    }

    public void setGenero(GeneroMusical genero) {
        this.genero = genero;
    }

    public List<Integrante> getIntegrantes() {
        return integrantes;
    }

    public void setIntegrantes(List<Integrante> integrantes) {
        this.integrantes = integrantes;
    }

    // ==========================
    // LER DADOS
    // ==========================

    public static Album lerDados(
            Scanner sc,
            List<Artista> artistas,
            List<Pessoa> pessoas) {

        System.out.print("ID: ");
        Integer id = Integer.parseInt(sc.nextLine());

        System.out.print("Título: ");
        String titulo = sc.nextLine();

        System.out.print("Ano de lançamento: ");
        int ano = Integer.parseInt(sc.nextLine());

        System.out.print("Mês: ");
        int mes = Integer.parseInt(sc.nextLine());

        System.out.print("Dia: ");
        int dia = Integer.parseInt(sc.nextLine());

        LocalDate data = LocalDate.of(ano, mes, dia);

        System.out.println("\nEscolha o artista principal:");

        for (int i = 0; i < artistas.size(); i++) {

            System.out.println(i + " - " + artistas.get(i).getNome());

        }

        int escolha = Integer.parseInt(sc.nextLine());

        Artista artista = artistas.get(escolha);

        System.out.println("\nGêneros:");

        GeneroMusical[] generos = GeneroMusical.values();

        for (int i = 0; i < generos.length; i++) {

            System.out.println(i + " - " + generos[i]);

        }

        int opGenero = Integer.parseInt(sc.nextLine());

        GeneroMusical genero = generos[opGenero];

       ```java
     List<Integrante> integrantes = new ArrayList<>();

     System.out.print("Quantidade de integrantes: ");
    int qtd = Integer.parseInt(sc.nextLine());

     for (int i = 0; i < qtd; i++) {

    System.out.println("\n=== PESSOAS DISPONÍVEIS ===");

    int contador = 0;

    for (Artista a : artistas) {

        if (a instanceof Pessoa) {

            System.out.println(contador + " - " + a.getNome());

            contador++;

        }

    }

    System.out.print("Escolha: ");
    int escolha = Integer.parseInt(sc.nextLine());

    contador = 0;

    Pessoa pessoaEscolhida = null;

    for (Artista a : artistas) {

        if (a instanceof Pessoa) {

            if (contador == escolha) {

                pessoaEscolhida = (Pessoa) a;
                break;

            }

            contador++;

        }

    }

    System.out.println("\nFunções:");

    FuncaoIntegrante[] funcoes = FuncaoIntegrante.values();

    for (int j = 0; j < funcoes.length; j++) {

        System.out.println(j + " - " + funcoes[j]);

    }

    int opFuncao = Integer.parseInt(sc.nextLine());

    integrantes.add(
        new Integrante(
            pessoaEscolhida,
            funcoes[opFuncao]
        )
    );

}
```


    // ==========================
    // TOSTRING
    // ==========================

    @Override
    public String toString() {

        return "ID: " + id +
                "\nTítulo: " + titulo +
                "\nData: " + dataLancamento +
                "\nArtista: " + artista.getNome() +
                "\nGênero: " + genero +
                "\nQuantidade de Integrantes: " +
                integrantes.size();

    }

    // ==========================
    // EQUALS
    // ==========================

    @Override
    public boolean equals(Object obj) {

        if (this == obj)
            return true;

        if (obj == null)
            return false;

        if (getClass() != obj.getClass())
            return false;

        Album other = (Album) obj;

        return Objects.equals(id, other.id);

    }

    @Override
    public int hashCode() {

        return Objects.hash(id);

    }

}
```

