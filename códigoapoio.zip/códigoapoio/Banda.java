```java
import java.util.Scanner;

public class Banda extends Artista {

    private Integer anoFormacao;

    public Banda(Integer id, String nome, String pais, Integer anoFormacao) {
        super(id, nome, pais);
        this.anoFormacao = anoFormacao;
    }

    public Integer getAnoFormacao() {
        return anoFormacao;
    }

    public void setAnoFormacao(Integer anoFormacao) {
        this.anoFormacao = anoFormacao;
    }

    public static Banda lerDados(Scanner sc) {

        System.out.print("ID: ");
        Integer id = Integer.parseInt(sc.nextLine());

        System.out.print("Nome: ");
        String nome = sc.nextLine();

        System.out.print("País: ");
        String pais = sc.nextLine();

        System.out.print("Ano de Formação: ");
        Integer anoFormacao = Integer.parseInt(sc.nextLine());

        return new Banda(id, nome, pais, anoFormacao);

    }

    @Override
    public String toString() {

        return super.toString() +
               "\nAno de Formação: " + anoFormacao;

    }

}
```
