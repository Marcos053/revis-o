package teste.provas.prova_chat4;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;

import teste.provas.prova_chat4.model.Conteudo;
import teste.provas.prova_chat4.model.Diretor;
import teste.provas.prova_chat4.model.Filme;
import teste.provas.prova_chat4.model.Genero;
import teste.provas.prova_chat4.model.Serie;

public class Plataforma implements Operacoes {
    public static List<Conteudo> catalogo = new ArrayList<>();
    public static List<Diretor> diretores = new ArrayList<>();

    public static void main(String[] args) {
        Plataforma p = new Plataforma();
        Scanner sc = new Scanner(System.in);
        int opcao = 0;
        

        while(opcao != 11){
            opcao = lerOpcaoMenu(sc);

            switch (opcao) {
                case 1 -> p.inserirDiretor();
                case 2 -> p.inserirFilme();
                case 3 -> p.inserirSerie();
                case 4 -> p.removerConteudo();
                case 5 -> p.listarConteudos();
                case 6 -> p.listarFilmes();
                case 7 -> p.listarSeries();
                case 8 -> p.filtrarPorGenero();
                case 9 -> {
                    Genero.imprimirTodos();
                    System.out.print("Opção: ");
                    Genero genero = Genero.valueOf(sc.nextInt());

                    p.filtrarFilmePorGenero(genero);
                }
                case 10 -> {
                    System.out.print("Finalizado (true/false): ");
                    Boolean finalizado = sc.nextBoolean();
                    p.filtrarSeriePorFinalizado(finalizado);
                }
            }
        }
    }

    @Override
    public void inserirDiretor() {
        Diretor d = Diretor.lerDados();
        Plataforma.diretores.add(d);
    }

    @Override
    public void inserirFilme() {
        Filme f = Filme.lerDados();
        Plataforma.catalogo.add(f);
    }

    @Override
    public void inserirSerie() {
        Serie s = Serie.lerDados();
        Plataforma.catalogo.add(s);
    }

    @Override
    public void removerConteudo() {
        Scanner sc = new Scanner(System.in);

        System.out.print("ID do Conteúdo: ");
        Integer idRemover = sc.nextInt();

        Plataforma.catalogo.removeIf(c -> c.getId().equals(idRemover));
    }

    @Override
    public void listarConteudos() {
        Plataforma.catalogo
            .stream()
            .sorted((c1, c2) -> c1.getTitulo().compareTo(c2.getTitulo()))
            .forEach(
                c -> System.out.println("\nÍndice: " + Plataforma.catalogo.indexOf(c) + c)
            );
    }

    @Override
    public void filtrarPorGenero() {
        Scanner sc = new Scanner(System.in);

        Genero.imprimirTodos();
        System.out.print("Opção: ");
        Genero genero = Genero.valueOf(sc.nextInt());

        Plataforma.catalogo
            .stream()
            .filter(c -> c.getGenero() == genero)
            .forEach(
                c -> System.out.println("\nÍndice: " + Plataforma.catalogo.indexOf(c) + c)
            );
    }
    
    public void listarFilmes(){
        Plataforma.catalogo
            .stream()
            .filter(
                new Predicate<Conteudo>() {
                    @Override
                    public boolean test(Conteudo c) {
                        if(c instanceof Filme) 
                            return true;
                        return false;
                    }
                }
            );
    // ou 
    Plataforma.catalogo
            .stream()
            .filter(c -> c instanceof Filme ? true : false)
            .forEach(
                c -> System.out.println("\nÍndice: " + Plataforma.catalogo.indexOf(c) + c)
            );
    }

    public void listarSeries(){
        Plataforma.catalogo
            .stream()
            .filter(c -> c instanceof Serie) // Não precisa do ? true : false. Próprio instanceof já retorna se é true ou false
            .forEach(
                c -> System.out.println("\nÍndice: " + Plataforma.catalogo.indexOf(c) + c)
            );
    }

    public void filtrarFilmePorGenero(Genero g){
         Plataforma.catalogo
            .stream()
            .filter(c -> c.getGenero() == g)
            .filter(c -> c instanceof Filme ? true : false)
            .forEach(
                c -> System.out.println("\nÍndice: " + Plataforma.catalogo.indexOf(c) + c)
            );
    }

    public void filtrarSeriePorFinalizado(Boolean finalizado){
         Plataforma.catalogo
            .stream()
            .filter(new Predicate<Conteudo>() {

                @Override
                public boolean test(Conteudo c) {
                    if(c instanceof Serie){
                        Serie s = (Serie) c;
                        if(s.getFinalizada() == finalizado)
                            return true;
                    }
                    return false;
                }
                
            })
            // ou
            .filter(c -> c instanceof Serie s && s.getFinalizada() == finalizado)
            //
            .forEach(
                c -> System.out.println("\nÍndice: " + Plataforma.catalogo.indexOf(c) + c)
            );
    }


    public static int lerOpcaoMenu(Scanner sc){
        System.out.println("\n*** MENU ***");
        System.out.println(
            "\n1) Inserir Diretor" + 
            "\n2) Inserir Filme" +
            "\n3) Inserir Série" + 
            "\n4) Remover Conteúdo" +
            "\n5) Listar Todos os Conteúdos" +
            "\n6) Listar Apenas Filmes" +
            "\n7) Listar Apenas Séries" +
            "\n8) Filtrar Conteúdos por Gênero" +
            "\n9) Filtrar filme por Gênero" +
            "\n10) Filtrar série por Finalizado" +
            "\n11) Sair"
        );
        System.out.print("Opção: ");

        return sc.nextInt();
    }
}
