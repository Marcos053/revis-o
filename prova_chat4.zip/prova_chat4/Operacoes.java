package teste.provas.prova_chat4;

public interface Operacoes {
    void inserirDiretor();
    void inserirFilme();
    void inserirSerie();
    void removerConteudo();
    void listarConteudos();
    void filtrarPorGenero();
}
