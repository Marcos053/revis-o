package teste.provas.prova_chat4.model;

import java.util.Scanner;

public class Diretor {
    private Integer id;
    private String nome;
    private String nacionalidade;

    public Diretor(Integer id, String nome, String nacionalidade) {
        this.id = id;
        this.nome = nome;
        this.nacionalidade = nacionalidade;
    }

    public static Diretor lerDados(){
        Scanner sc = new Scanner(System.in);

        System.out.print("\nID: ");
        Integer id = sc.nextInt();
        sc.nextLine();

        System.out.print("Nome: ");
        String nome = sc.nextLine();

        System.out.print("Nacionalidade: ");
        String nacionalidade = sc.nextLine();

        Diretor d = new Diretor(id, nome, nacionalidade);

        return d;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNacionalidade() {
        return nacionalidade;
    }

    public void setNacionalidade(String nacionalidade) {
        this.nacionalidade = nacionalidade;
    }

    @Override
    public String toString(){
        return "\nDiretor" + 
                "\nID: " + this.id +
                "\nNome: "+ this.nome +
                "\nNacionalidade: " + this.nacionalidade;
    }
}
