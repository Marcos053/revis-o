package teste.provas.prova_chat4.model;

import java.util.Scanner;

import teste.provas.prova_chat4.Plataforma;

public class Serie extends Conteudo {
    private Integer numeroTemporadas;
    private Boolean finalizada;

    public Serie(Integer id, String titulo, Integer anoLancamento, Diretor diretor, Genero genero,
            Integer numeroTemporadas, Boolean finalizada) {
        super(id, titulo, anoLancamento, diretor, genero);
        this.numeroTemporadas = numeroTemporadas;
        this.finalizada = finalizada;
    }

    public static Serie lerDados(){
        Scanner sc = new Scanner(System.in);

        System.out.print("\nID: ");
        Integer id = sc.nextInt();
        sc.nextLine();

        System.out.print("Tíutlo: ");
        String titulo = sc.nextLine();

        System.out.print("Ano Lançamento: ");
        Integer anoLancamento = sc.nextInt();
        sc.nextLine();

        System.out.print("Número de Temporadas: ");
        Integer numeroTemporadas = sc.nextInt();
        sc.nextLine();

        System.out.print("Está finalizada (true/false): ");
        Boolean finalizada = sc.nextBoolean();
        sc.nextLine();

        Plataforma.diretores.forEach(d -> System.out.println(d));
        System.out.print("\nID do diretor: ");
        Integer idEscolhido = sc.nextInt();
        Diretor diretor = Plataforma.diretores.stream().filter(d -> d.getId() == idEscolhido).findFirst().get();

        Genero.imprimirTodos();
        System.out.print("Opção: ");
        Genero genero = Genero.valueOf(sc.nextInt());

        Serie s = new Serie(id, titulo, anoLancamento, diretor, genero, numeroTemporadas, finalizada);

        return s;
    }

    public Integer getNumeroTemporadas() {
        return numeroTemporadas;
    }

    public void setNumeroTemporadas(Integer numeroTemporadas) {
        this.numeroTemporadas = numeroTemporadas;
    }

    public Boolean getFinalizada() {
        return finalizada;
    }

    public void setFinalizada(Boolean finalizada) {
        this.finalizada = finalizada;
    }

    @Override
    public String toString(){
        return "\nSérie"+
                super.toString() +
                "\nNúmero de Temporadas: " + this.numeroTemporadas +
                "\nEstá Finalizada: " + (this.finalizada ? "Sim" : "Não");
    }
}
