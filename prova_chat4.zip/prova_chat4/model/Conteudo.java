package teste.provas.prova_chat4.model;

public abstract class Conteudo {
    private Integer id;
    private String titulo;
    private Integer anoLancamento;
    private Diretor diretor;
    private Genero genero;

    public Conteudo(Integer id, String titulo, Integer anoLancamento, Diretor diretor, Genero genero) {
        this.id = id;
        this.titulo = titulo;
        this.anoLancamento = anoLancamento;
        this.diretor = diretor;
        this.genero = genero;
    }

    public Integer getId() {
        return id;
    }


    public void setId(Integer id) {
        this.id = id;
    }


    public String getTitulo() {
        return titulo;
    }


    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }


    public Integer getAnoLancamento() {
        return anoLancamento;
    }


    public void setAnoLancamento(Integer anoLancamento) {
        this.anoLancamento = anoLancamento;
    }


    public Diretor getDiretor() {
        return diretor;
    }


    public void setDiretor(Diretor diretor) {
        this.diretor = diretor;
    }


    public Genero getGenero() {
        return genero;
    }


    public void setGenero(Genero genero) {
        this.genero = genero;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Conteudo other = (Conteudo) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
    
        return true;
    }

    @Override
    public String toString(){
        return "\nID: " + this.id +
                "\nTítulo: " + this.titulo +
                "\nAno de Lançamento: " + this.anoLancamento +
                this.diretor.toString() +
                "\nGênero: " + this.genero.getLABEL();
    }
}
