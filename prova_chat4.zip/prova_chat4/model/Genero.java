package teste.provas.prova_chat4.model;

public enum Genero {
    ACAO(1, "Ação"), 
	COMEDIA(2, "Comédia"), 
	DRAMA(3, "Drama"), 
	TERROR(4, "Terror"),
    FICCAO(5, "Ficção"),
    DOCUMENTARIO(6, "Documentário");

	private final int ID;
	private final String LABEL;

	Genero(int id, String label) {
		this.ID = id;
		this.LABEL = label;
	}

	public static Genero valueOf(int id) {
		for (Genero g : Genero.values()) 
			if (g.getID() == id) 
				return g;

		return null;
	}

	public static void imprimirTodos() {
		System.out.println("*** Generos ***");
		for (Genero g : values()) 
			System.out.println(g.getID() + " - " + g.getLABEL());
	}

	public int getID() {
		return ID;
	}

	public String getLABEL() {
		return LABEL;
	}
}
