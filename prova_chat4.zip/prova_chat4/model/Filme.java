package teste.provas.prova_chat4.model;

import java.util.Scanner;

import teste.provas.prova_chat4.Plataforma;

public class Filme extends Conteudo {
    private Integer duracaoMinutos;

    public Filme(Integer id, String titulo, Integer anoLancamento, Diretor diretor, Genero genero, Integer duracaoMinutos) {
        super(id, titulo, anoLancamento, diretor, genero);
        this.duracaoMinutos = duracaoMinutos;
    }
    
    public static Filme lerDados(){
        Scanner sc = new Scanner(System.in);

        System.out.print("\nID: ");
        Integer id = sc.nextInt();
        sc.nextLine();

        System.out.print("Título: ");
        String titulo = sc.nextLine();

        System.out.print("Ano Lançamento: ");
        Integer anoLancamento = sc.nextInt();
        sc.nextLine();

        System.out.print("Duração em Minutos: ");
        Integer duracaoMinutos = sc.nextInt();
        sc.nextLine();

        Plataforma.diretores.forEach(d -> System.out.println(d));
        System.out.print("\nID do diretor: ");
        Integer idEscolhido = sc.nextInt();
        Diretor diretor = Plataforma.diretores.stream().filter(d -> d.getId() == idEscolhido).findFirst().get();

        Genero.imprimirTodos();
        System.out.print("Opção: ");
        Genero genero = Genero.valueOf(sc.nextInt());

        Filme f = new Filme(id, titulo, anoLancamento, diretor, genero, duracaoMinutos);

        return f;
    }

    public Integer getDuracaoMinutos() {
        return duracaoMinutos;
    }

    public void setDuracaoMinutos(Integer duracaoMinutos) {
        this.duracaoMinutos = duracaoMinutos;
    }

    @Override
    public String toString(){
        return "\nFilme"+
                super.toString() +
                "\nDuração em Minutos: " + this.duracaoMinutos;
    }
}
