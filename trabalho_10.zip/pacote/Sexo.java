package pacote;

public enum Sexo {
	
	MASCULINO(1, "Masculino"),
	FEMININO(2, "Feminino");

	private final Integer ID;
	private final String LABEL;
	
	Sexo(Integer id, String label) {
		this.ID = id;
		this.LABEL = label;
	}
	
	public static Sexo valueOf(Integer id) {
		
		for(Sexo s : Sexo.values()) {
			if(s.ID.equals(id)) {
				return s;
			}
			
		}
		return null;
	}
	
	public static void imprimir() {
		
		for(Sexo s : Sexo.values()) {
			System.out.println(s.ID + " - " + s.LABEL);
		}
		
		
	}

	public Integer getID() {
		return ID;
	}

	public String getLABEL() {
		return LABEL;
	}

	
	
	
	
}
