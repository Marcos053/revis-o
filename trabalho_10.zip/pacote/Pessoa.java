package pacote;

import java.util.Scanner;

public  class Pessoa implements Impressao {
	
	private String nome;
	private int idade;
	private Sexo sexo;
	
	
	public static Pessoa lerDados() {
		Scanner sc = new Scanner(System.in);
		Pessoa p = new Pessoa();
		
		System.out.println("Digite seu nome: ");
		p.setNome(sc.nextLine());
		
		System.out.println("Digite sua idade: ");
		p.setIdade(sc.nextInt());
		
		System.out.println("Sexo: ");
		Sexo.imprimir();
		
		System.out.println("Opção: ");
		
		Sexo sexo = Sexo.valueOf(sc.nextInt());

		 if(sexo != null) {
			 p.setSexo(sexo);
		 }

		    else {

		        System.out.println("Sexo inválido!");

		    }

		
		return p;
		
		
	}
	
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	
	
	
	public Sexo getSexo() {
		return sexo;
	}


	public void setSexo(Sexo sexo) {
		this.sexo = sexo;
	}


	@Override
	public String toString() {
		return "Nome: " + this.nome + "\nIdade: " + this.idade + "\nSexo: " + this.sexo.getLABEL();
	}
	
	@Override 
	public void imprimir() {
		System.out.println(this);
	}
	
	

}
