package pacote;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Main {
	
	public static void main(String[] args) {
		List<Pessoa> lista = new ArrayList<>();
		
		for(int i = 0; i < 5; i++) {
			Pessoa p = Pessoa.lerDados();
			lista.add(p);
		}
		
		System.out.println("===== LISTA =====");
		imprimirLista(lista);
		
		System.out.println("===== LISTA DE HOMENS =====");
		imprimirFiltro(lista, Sexo.MASCULINO);
		
		System.out.println("===== LISTA ORDENADA POR NOME =====");
		imprimirListaOrdenadaPorNome(lista);
		
		System.out.println("===== LISTA ORDENADA POR IDADE =====");
		imprimirListaOrdenadaPorIdade(lista);
		
		System.out.println("===== LISTA ORDENADA POR SEXO =====");
		imprimirListaOrdenadaPorSexo(lista);
		
		
		System.out.println("- - - - -");
		System.out.println("===== LISTA COM LAMBDA PARA NOME =====");
		imprimirListaLambdaNome(lista);
		
		System.out.println("===== LISTA COM LAMBDA PARA IDADE =====");
		imprimirListaLambdaIdade(lista);
		
		System.out.println("===== LISTA COM LAMBDA PARA SEXO =====");
		imprimirListaLambdaSexo(lista);
		
	}
	
	public static void imprimirLista(List<Pessoa> lista) {
	
	if(lista.isEmpty()) {

        System.out.println("Nenhuma pessoa cadastrada.");

        return;

    }
	
	for(Pessoa p : lista) {
		System.out.println(p);
		System.out.println("-------------------");
	}
  }
	
	public static void imprimirFiltro(List<Pessoa> lista, Sexo sexo) {
		
		
		for(Pessoa p : lista) {
			if(p.getSexo() == sexo) {
				System.out.println(p);
				System.out.println("-------------------");
			}
		}
		
		
		
		
	}
	
	public static void imprimirListaOrdenadaPorNome(List<Pessoa> lista) {
		lista.sort(new Comparator<Pessoa>()  {
			@Override
			public int compare(Pessoa p1, Pessoa p2) {
			return p1.getNome().compareTo(p2.getNome());
			}
			
			
			
		});
		imprimirLista(lista);
		
	}
	
	public static void imprimirListaOrdenadaPorIdade(List<Pessoa> lista) {
		lista.sort(new Comparator<Pessoa>() {
			@Override
			public int compare(Pessoa p1, Pessoa p2) {
				return Integer.compare(p1.getIdade(), p2.getIdade());
				
			}
			
			
		});
		
		imprimirLista(lista);
	}
	
	public static void imprimirListaOrdenadaPorSexo(List<Pessoa> lista) {
		lista.sort(new Comparator<Pessoa>() {
			@Override
			public int compare(Pessoa p1, Pessoa p2) {
				return p1.getSexo().getID().compareTo(p2.getSexo().getID());
			}
		});
		imprimirLista(lista);
	}
	
	public static void imprimirListaLambdaNome(List<Pessoa> lista) {
		lista.sort((p1, p2) -> p1.getNome().compareTo(p2.getNome()) );
		imprimirLista(lista);
	}
	
	public static void imprimirListaLambdaIdade(List<Pessoa> lista) {
		lista.sort((p1, p2) -> Integer.compare(p1.getIdade(), p2.getIdade()) );
		imprimirLista(lista);
	}
	
	public static void imprimirListaLambdaSexo(List<Pessoa> lista) {
		lista.sort((p1, p2) -> p1.getSexo().getID().compareTo(p2.getSexo().getID()));
		
		imprimirLista(lista);
	}
	
}
	
