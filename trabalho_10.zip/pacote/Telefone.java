package pacote;

public class Telefone implements Impressao {
	
	private String numero;
	private String codigoArea;
	
	
	
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public String getCodigoArea() {
		return codigoArea;
	}
	public void setCodigoArea(String codigoArea) {
		this.codigoArea = codigoArea;
	}
	
	@Override
	public String toString() {
		return "Numero: " + this.numero + " - " + "\nCodigo: " + this.codigoArea;
	}
	
	@Override 
	public void imprimir() {
		System.out.println(this);
	}
	
	

}
