package pacote;

public interface Impressao {
	
	public void imprimir();

}
